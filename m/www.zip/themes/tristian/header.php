<script>
<!--
function BlurLinks(){
lnks=document.getElementsByTagName('a');
for(i=0;i<lnks.length;i++){
lnks[i].onfocus=new Function("if(this.blur)this.blur()");
}
}
onload=BlurLinks;
-->
</script>
<div align="center">

<table bgcolor="#ffffff"  cellspacing="0" cellpadding="0" border="0" width="100%" style="border:solid 1px silver">
<tr>
<td  width="100%" ><table   cellspacing="2" cellpadding="0" border="0" width="100%">
<tr>
<!-- beginn kopf1-->
<td    width="190" align="center" >
<table width="190" cellspacing="0" cellpadding="0" border="0"  align="center">
<tr>
<td   width="190"   class="leiste" >
<table cellspacing="0" cellpadding="0" border="0" width="190" >
<tr>
<td  align="center"><table border="0" cellpadding="0" cellspacing="0"  width="100%" >
<tr>
<td align="center" style="font-family:arial;font-size:8pt;color:black;font-weight:bold"><script
language="JavaScript">
<!--

var jetzt = new Date();

Wochentagsbezeichnung = new Array ("�����������","�����������","�������","�����","�������","�������","�������");

Monatsbezeichnung = new Array ("������","�������","����","������","���","����","����","������","��������","�������","������","�������");

var Tag = jetzt.getDate();
var Wochentag = jetzt.getDay();
var Monat = jetzt.getMonth();
var Jahr = jetzt.getYear();

document.write( Wochentagsbezeichnung[Wochentag] + ", " + Tag + ". " + Monatsbezeichnung[Monat] + " " + Jahr + "<BR>");


// -->
</script></td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table></td><td  align="center"  width="100%"  class="leiste"><?php echo $_SERVER['HTTP_HOST']; ?></td>

<!-- ende kopf1-->
</tr>
<tr>
<!-- logo-->
<td  bgcolor="#e6e6e6" align="center" style="border:solid 1px silver"      width="190" height="72">&nbsp;</td><td  bgcolor="#e6e6e6" align="center" style="border:solid 1px silver" width="100%" height="72">��� ������ �����</td>
<!-- logo ende-->
</tr>

<!-- beginn kopf2-->
<td  width="190"  >
<table cellspacing="0" cellpadding="0" border="0">
<tr>
<td   width="100%"   class="leiste" >
<table cellspacing="0" cellpadding="0" border="0" width="190" align="center">
<tr>
<td>&nbsp;</td>
</tr>
</table>
</td>
</tr>
</table></td>
<td  align="center"  width="100%" class="leiste" ><?php echo $Siteman->content; ?></td>
</tr>
<!-- ende kopf2-->


<tr>
<td   valign="top" width="190"  class="nav" bgcolor="#e6e6e6" >
<br>
<!--Beginn Rubrik 1 linke Seite-->
<table bgcolor="#ffffff" width="170" border="0" cellpadding="0" cellspacing="2"    id="menu" align="center" style="border:solid 1px silver" >
<tr>
<td class="rubrik">&nbsp;����

</td>
</tr>
<tr>
<td >
<?php $Siteman->show_menu(); ?>
</td>
</tr>

</table>

<!--Ende Rubrik 1 linke Seite-->
<br>
<!--Beginn Rubrik 2 linke Seite-->
<table bgcolor="#ffffff" width="170" border="0" cellpadding="0" cellspacing="2"    id="menu" align="center" style="border:solid 1px silver" >
<tr>
<td class="rubrik">&nbsp;������������
</td>
</tr>
<tr>
<td width="170" >
<?php $Siteman->show_loginbox(); ?>
</td>
</tr>
</table>
<!--Ende Rubrik 2 linke Seite-->
<!--Ende Menue linke Seite-->
</td>
<td valign="top" bgcolor="#e6e6e6"  width="100%" height="440" style="border:solid 1px silver"  >
<!-- beginn hauptinhaltstabelle--><table border="0" cellpadding="0" cellspacing="0"  width="100%" >
<tr>
<!-- abstand links vom inhalt-->   <td  ><img src="themes/tristian/images/space.gif" width="20" height="440" border="0" alt=""></td><!-- ende abstand links vom inhalt-->
<td valign="top" width="100%" >
          <!--            <td colspan="2" class="content" > -->
                        <!-- content start -->