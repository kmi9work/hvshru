</td>
</tr>
</table></td>
</tr>
</table>
</td>
</tr>
</table>
<!-- ende haupt--></td>
</tr>
<tr>
<td>


<!-- fuss -->
<table bgcolor="black" border="0" cellpadding="0" cellspacing="0"  width="750" >
<tr>
<td><table border="0" cellpadding="2" cellspacing="1"  width="100%">
<tr>
<td width="100%" background="themes/think_blue/images/balken.gif"><img src="themes/think_blue/images/space_trans.gif" width="1" height="8" border="0" alt=""></td>
</tr>
<tr>
<td  width="100%"     bgcolor="#4E6F81" >
<table border="0" cellpadding="0" cellspacing="0"    width="100%">
<tr>
<td  style="font-size:8pt;" > Powered by <a href="http://sitem.sourceforge.net" target="_blank" >Siteman</a> 
CMS Version <?php echo $Siteman->version; ?> | ������� ��������� <a href="http://siteman.alfaspace.net/" target="_blank" title="Siteman Russian Support">Siteman Rus</a>.<br /><small>�������� ������������� �� <?php echo $Siteman->get_loadtime(); ?> ������.
						<br />����� �������: <a href="http://www.mwulf.de/" target="_blank">Marcus Schwager</a></small></td><td  align="right"  ><a href="javascript:history.go(-1);" onMouseOver="window.status='&nbsp;�����'; return true" onMouseOut="window.status=''" ><img src="themes/think_blue/images/back.gif" width="22" height="22" border="0" alt="back" title="�����" style="border:solid 1px black"></a>&nbsp;<a href="#" onMouseOver="window.status='&nbsp;������'; return true" onMouseOut="window.status=''"><img src="themes/think_blue/images/top.gif" width="22" height="22" border="0" alt="������" title="top" style="border:solid 1px black"></a>&nbsp;</td>
</tr>
</table>
</td>
<tr>
<td width="100%" background="themes/think_blue/images/balken.gif"><img src="themes/think_blue/images/space_trans.gif" width="1" height="8" border="0" alt=""></td>
</tr>
</table></td>
</tr>
</table>
<!-- ende fuss--></td>
</tr>
</table></div>
