<?php $theme_single = 1; ?>
<script>
<!--
function BlurLinks(){
lnks=document.getElementsByTagName('a');
for(i=0;i<lnks.length;i++){
lnks[i].onfocus=new Function("if(this.blur)this.blur()");
}
}

onload=BlurLinks;
-->
</script>
<SCRIPT LANGUAGE="JavaScript">

function uhr ()
 {

   var jahr;
   var monat;
   var tag;
   var stunden;
   var minuten;
   var sekunden;


       var AktuellesDatum=new Date();

       jahr=AktuellesDatum.getFullYear ();
       monat=AktuellesDatum.getMonth ()+1;
       tag=AktuellesDatum.getDate ();
       stunden=AktuellesDatum.getHours ();
       minuten=AktuellesDatum.getMinutes ();
       sekunden=AktuellesDatum.getSeconds ();

       window.document.Datum.Date.value=tag+"."+monat+"."+jahr;
       window.document.zeit.Time.value=stunden+":"+minuten+":"+sekunden;
       window.setTimeout ('uhr()',1000);
 }
window.setTimeout ('uhr()',1000);
</SCRIPT>
<!-- aussen-->
<div align="center"><table border="0" cellpadding="0" cellspacing="3"  width="760">
<tr>
<td><!-- banner-->
<table bgcolor="black" border="0" cellpadding="0" cellspacing="0"  width="750" >
<tr>
<td ><table border="0" cellpadding="2" cellspacing="1"  width="750">
<tr>
<td background="themes/think_blue/images/balken.gif"  bgcolor="#4E6F81" align="right" >www.mwulf.de</td>
</tr>
<tr>
<td bgcolor="#587c92" height="62">
	<table width=100%><tr><td>
<img src="themes/think_blue/images/banner_schreibtisch.jpg" width="468" height="60" border="0" style="border:solid 1px black" alt="Homepage- und Layout-Tipps auf der Schreibtischseite" align="middle"></a></td>
<td align="center"><?php echo $Siteman->content; ?></td></tr></table>
</td>
</tr>
<tr>
<td width="100%" background="themes/think_blue/images/balken.gif"    bgcolor="#4E6F81"align="right">
<table border="0" cellpadding="0" cellspacing="0"  width="100%" >
<tr>
<td align="right" width="100%"><FORM style="margin-bottom:0px;padding-top:3px;" NAME="Datum"><INPUT SIZE=10 NAME="Date" style="height:20px;font-size:9pt;background-color:#89a9b8;color:white;padding:2px"></FORM></td><td >&nbsp;&nbsp;&nbsp;&nbsp;</td><td valign="top"  ><FORM NAME="zeit" style="margin-bottom:0px;padding-top:3px;"><INPUT SIZE=10 NAME="Time" style="height:20px;font-size:9pt;background-color:#89a9b8;color:white;padding:2px" ></FORM></td><td>&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
</td>
</tr>
</table></td>
</tr>
</table>
<!-- ende banner--></td>
</tr>
<tr>
<td  valign="top"   ><!-- hauptbereich men� und inhalt-->
<table border="0" cellpadding="0" cellspacing="0"  width="750">
<tr>
<td  valign="top" height="870"><!-- men�s-->
<table bgcolor="black" border="0" cellpadding="0" cellspacing="0"  width="160" >
<tr>
<td valign="top" >
<table width="160"  border="0" cellpadding="0" cellspacing="1" id="menu1" >
<tr>
<td  bgcolor="#4E6F81" width="160"   height=20 style="padding:4px"  background="themes/think_blue/images/balken.gif"  >&nbsp;&nbsp;����</td>
</tr>
<tr>
<td   width="160"  background="themes/think_blue/images/back_button.jpg" >
<?php $Siteman->show_menu(); ?>

</td>
</tr>
</table>
</td>
</tr></table><!-- ende men� 1-->
<br>
<!-- men� 2-->
<table bgcolor="black" border="0" cellpadding="0" cellspacing="0"  width="160" >
<tr>
<td valign="top" >
<table width="160"  border="0" cellpadding="0" cellspacing="1" id="menu1" >
<tr>
<td  bgcolor="#4E6F81" width="160"   height=20 style="padding:4px" background="themes/think_blue/images/balken.gif" >&nbsp;&nbsp;������������</td>
</tr>
<tr>
<td   width="160"  background="themes/think_blue/images/back_button.jpg" >
<?php $Siteman->show_loginbox(); ?>
</td>
</tr>
</table>
</td>
</tr></table><!-- ende men� 2-->
</td>
<td  >&nbsp;&nbsp;</td>
<td  width="100%" valign="top" >
<!-- inhalt -->
<table bgcolor="black" border="0" cellpadding="0" cellspacing="0"  width="100%" >
<tr>
<td valign="top"  height="100%"><table border="0" cellpadding="15" cellspacing="1"  width="100%">
<tr>
<td valign="top"  bgcolor="#89a9b8" height="870">

                        <!-- content start -->