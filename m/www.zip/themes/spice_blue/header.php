<script>
<!--
function BlurLinks(){
lnks=document.getElementsByTagName('a');
for(i=0;i<lnks.length;i++){
lnks[i].onfocus=new Function("if(this.blur)this.blur()");
}
}

onload=BlurLinks;
-->
</script>

<div align="center"><table class="aussen" cellspacing="0" cellpadding="0" border="0" width="100%">
<tr>
<td>
<!--kopf-->
<table cellspacing="0" cellpadding="0" border="0"  class="kopfaussen" width="100%">
<tr>
<td width="100%"><table  cellspacing="0" cellpadding="0" border="0" width="100%">
<tr>
<td width="100%"><table   cellspacing="0" cellpadding="0" border="0"  class="kopf" width="100%">
<tr>
<td  width="100%" height="21" >
<table  height="21" cellspacing="0" cellpadding="0" border="0" width="100%">
<tr>
<td  align="right" height="21" width="100%"  ><table   cellspacing="0" cellpadding="0" border="0" width="100%" align="right" height="21">
<tr>
<td  align="right" width="100%"  height="21" >
<!--hpname-->
<table  cellspacing="0" cellpadding="0" border="0" width="100%" align="right" height="21">
<tr>
<td align=right width="100%" height="21"class="leisteoben" >www.mwulf.de</td>
</tr>
</table>
<!--ende hpname-->
</td>
</tr>
</table></td>
</tr>
<tr>
<td  class="banner"     width="100%" ><table width=100%><tr><td>
<img src="themes/spice_blue/images/logo02.gif" alt="" width="468" height="60" border="0" style="border:solid 1px #31485b;"></td><td align="right" valign=bottom > <?php echo $Siteman->content; ?> </td></tr></table>
</td>
</tr>

</table>

</td>
</tr>
</table>
<!--kopf ende--></td>
</tr>
</table></td>
</tr>
</table>

<table     cellspacing="0" cellpadding="0" border="0" width="100%"    >
<tr>
<td  class="backnav" valign="top"  width="192" >
<table width="192"   cellspacing="0" cellpadding="0" border="0"  >
<tr>
<td>
<!-- men� li 1-->

<table bgcolor="#CEDCE3" cellspacing="0" cellpadding="0" border="0" width="192">
<tr>
<td   valign="top"  class="label">����</td>
</tr>
<tr>
<td   valign="top" class="inhaltnav" >
<?php $Siteman->show_menu(); ?>
</td>
</tr>
</table>
<!-- ende men� li 1-->
</td>
</tr>

<tr>
<td class="space"><img src="themes/spice_blue/images/space.gif" width="1" height="10" border="0" alt=""></td>
</tr>

<tr>
<td>
<!-- men� li 2-->
<table cellspacing="0" cellpadding="2" border="0" width="192">
<tr>
<td  valign="top" class="label">������������</td>
</tr>
<tr>
<td   valign="top" class="inhaltnav" >
<?php $Siteman->show_loginbox(); ?>
</td>
</tr>
</table>
<!-- ende men� li 2-->
</td>
</tr>
<td class="space"><img src="themes/spice_blue/images/space.gif" width="1" height="10" border="0" alt=""></td>
</tr>

</table>


</td>
<td class="backinhalt"  valign="top"    align="center" width="100%" >