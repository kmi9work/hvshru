</td>
                    </tr>
                    <tr> 
                      <td colspan="2" class="content">
                        </td>
                    </tr>
                    <tr>
                      <td colspan="2" class="content">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td colspan="2" class="content-footer"> Powered by <a href="http://sitem.sourceforge.net" target="_blank" >Siteman</a> 
                        CMS Version <?php echo $Siteman->version; ?> | ������� ��������� <a href="http://siteman.alfaspace.net/" target="_blank" title="Siteman Russian Support">Siteman Rus</a>.<br /><small>�������� ������������� �� <?php echo $Siteman->get_loadtime(); ?> ������.</small></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table>
    </td></tr>

  <tr>
    </tr>
</table>