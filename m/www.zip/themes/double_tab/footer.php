<!-- ende inhalt-->
<!-- abstand nach unten - mehr oder weniger <br>-->
<br>
<!-- ende abstand nach unten-->
</td><!-- abstand rechts vom inhalt-->   <td width="20" ><img src="themes/double_tab/images/space.gif" width="20" height="1" border="0" alt=""></td><!-- ende abstand rechts vom inhalt-->
</tr>
</table><!--ende hauptinhaltstabelle-->





</td>
</tr>
<tr>
<td  bgcolor="#646B84" class="leiste" >&nbsp;<span style="font-size:8pt">Powered by <a href="http://sitem.sourceforge.net" target="_blank" >Siteman</a> 
CMS Version <?php echo $Siteman->version; ?> | ������� ��������� <a href="http://siteman.alfaspace.net/" target="_blank" title="Siteman Russian Support">Siteman Rus</a>.</span></td><td align="center"  bgcolor="#646B84" class="leiste" style="font-size:8pt"><small>�������� ������������� �� <?php echo $Siteman->get_loadtime(); ?> ������.
						<br />����� �������: <a href="http://www.mwulf.de/" target="_blank">Marcus Schwager</a></small></td><td bgcolor="#646B84" class="leiste"  align="right" ><a href="javascript:history.go(-1);" onMouseOver="window.status='&nbsp;�����'; return true" onMouseOut="window.status=''" ><img src="themes/double_tab/images/b.gif" width="15" height="15" border="0" alt="" style="border:solid 1px silver" align="middle"></a>&nbsp;<a href="#" onMouseOver="window.status='&nbsp;������'; return true" onMouseOut="window.status=''"><img src="themes/double_tab/images/t.gif" width="15" height="15" border="0" alt="" style="border:solid 1px silver" align="middle"></a>&nbsp;&nbsp;</td>
</tr>
</table></td>
</tr>
</table>
</div>


</td>
                    </tr>
                    <tr> 
                      <td colspan="2" class="content">
                        </td>
                    </tr>
                    <tr>
                      <td colspan="2" class="content"></td>
                    </tr>
                    <tr> 
                      <td colspan="2" class="content-footer"> </td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table>
    </td></tr>

  <tr>
    </tr>
</table>