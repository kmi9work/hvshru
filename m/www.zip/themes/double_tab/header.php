<script>
<!--
function BlurLinks(){
lnks=document.getElementsByTagName('a');
for(i=0;i<lnks.length;i++){
lnks[i].onfocus=new Function("if(this.blur)this.blur()");
}
}

onload=BlurLinks; window.setTimeout('datumuhr()',1000);
-->
</script>
<script src="themes/double_tab/datumuhr.js" type="text/javascript"></script>


<!-- body bgcolor="#e6e6e6" text="black" topmargin="8" marginheight="8"  leftmargin="8" marginwidth="8"   -->

<div align="center">

<table bgcolor="#000000"  cellspacing="0" cellpadding="0" border="0" width="100%" >
<tr>
<td width="100%" ><table   cellspacing="1" cellpadding="0" border="0" width="100%">
<tr>
<td align="right"  width="100%" colspan="3" bgcolor="#646B84" class="leiste">
<table cellspacing="0" cellpadding="0" border="0" >
<tr>
<td valign="top" align="right" ><form  name="anzeige"><input type="text" name="date" class="datum" size="7"></form></td><td>&nbsp;</td>
<td align="right"><form name="anzeige2" ><input type="text" name="time" size="7" class="zeit" ></form></td><td >&nbsp;</td>
</tr>
</table>

</td>
</tr>
<tr>
<td bgcolor="#ffffff" valign="top" width="140" rowspan="3" >

<!--Beginn Menue linke Seite-->
<table  border="0" cellpadding="0" cellspacing="0"  width="140"  >
<tr>
<td ><img src="themes/double_tab/images/space.gif" width="1" height="72" border="0" alt=""></td>
</tr>
<tr>
<td valign="top" align="center" width="100%" >
<table width="140" border="0" cellpadding="0" cellspacing="0"    id="menu" align="center" >
<tr>
<td class="rubrik">&nbsp;���� </td>
</tr>
<tr>
<td ><?php $Siteman->show_menu(); ?></td>
</tr>
</table>

</td>
</tr>
</table>
<!--Ende Menue linke Seite-->
<!-- Rubrik 3 -->

<!-- Ende Rubrik 3 -->
<!-- Rubrik 5 -->

<!-- Ende Rubrik 5 -->

</td>
<td valign="middle" align="center" bgcolor="#ffffff" width="100%" height="72"><img src="themes/double_tab/images/banner.jpg" width="468" height="60" border="1" alt="" style="border:solid 1px #666666"></td>
<td bgcolor="#ffffff" valign="top" width="175" rowspan="3" >

<!--Beginn Menue rechte Seite-->
<table  border="0" cellpadding="0" cellspacing="0"  width="140"  >
<tr>
<td ><img src="themes/double_tab/images/space.gif" width="1" height="72" border="0" alt=""></td>
</tr>
<tr>
<td valign="top" align="center" width="100%" >
<table width="140" border="0" cellpadding="0" cellspacing="0"    id="menu" align="center" >
<tr>
<td align="right" class="rubrik" >������������&nbsp;</td>
</tr>
<tr>
<td align="right"><?php $Siteman->show_loginbox(); ?></td>
</tr>
</table>

</td>
</tr>
</table>
<!--Ende Menue rechte Seite-->

<!-- Rubrik 4 -->

<!-- Ende Rubrik 4 -->

</td>

</tr>
<tr>
<td width="100%" align="center" bgcolor="#6e7591" class="leiste" ><?php echo $Siteman->content; ?></td>
</tr>
<tr>
<td valign="top" bgcolor="#e6e6e6"  width="100%" height="450" >
<br>

<!-- beginn hauptinhaltstabelle--><table border="0" cellpadding="0" cellspacing="0"  width="100%" >
<tr>
<!-- abstand links vom inhalt-->   <td width="20" ><img src="themes/double_tab/images/space.gif" width="20" height="1" border="0" alt=""></td><!-- ende abstand links vom inhalt-->
<td valign="top" width="100%">

