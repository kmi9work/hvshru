	<!-- content end -->
		</td>
	  </tr></table>
	</td>
  </tr></table>
  <br />
</td>
<td>
  <img src="./themes/ib2/images/pixel.gif" width="10" height="1" alt="" />
</td>
<td valign="top" bgcolor="#eeeeee"><img src="./themes/ib2/images/pixel.gif" width="170" height="1" alt="" /><br />
  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="border"><tr>
	<td>
	  <table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
		<td class="blocktitle">
		  <img src="./themes/ib2/images/nav_m.gif" width="8" height="8" border="0" alt="" />&nbsp;������������
		</td>
	  </tr></table>
	  <table border="0" width="100%" cellspacing="2" cellpadding="2" class="blocktext"><tr>
		<td align="center">
		  <?php $Siteman->show_loginbox(); ?>
		</td>
	  </tr></table>
	</td>
  </tr></table>
  <br />
  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="border"><tr>
	<td>
	  <table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
		<td class="blocktitle">
		  <img src="./themes/ib2/images/nav_m.gif" width="8" height="8" border="0" alt="">&nbsp;����������
		</td>
	  </tr></table>
	  <table border="0" width="100%" cellspacing="2" cellpadding="2" class="blocktext"><tr>
		<td align="center"><br />
		  <a href="http://txtsql.dotgeek.org/" target="_blank">
		  <img src="./themes/ib2/images/txtsql.gif" border="0" alt="Powered with txtSQL" width="88" height="31" /></a><br /><br />
		</td>
	  </tr></table>
	</td>
  </tr></table><br />
</td>
</tr></table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="border"><tr><td>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" class="footer"><tr>
    <td width="100%">
	  Powered by <a href="http://sitem.sourceforge.net/" target="_blank" title="Siteman CMS">Siteman CMS</a> <?php echo $Siteman->version; ?> | ������� ��������� <a href="http://siteman.alfaspace.net/" target="_blank" title="Siteman Russian Support">Siteman Rus</a>
	  <br />��������� ���� "IPB2" (����� <a href="http://www.smallnuke.com/" target="_blank" title="SmallNuke.com">SmallNuke.com</a>) ��� Siteman 2 - <a href="mailto:dmblack[at]bk[dot]ru" target="_blank" title="dmblack@bk.ru">Mr. D.M.Black</a>
	  <br />�������� ������������� �� <?php echo $Siteman->get_loadtime(); ?> ������. �������� � ����: <?php echo $db->query_count(); ?>
	</td>
  </tr></table>
</td>
</tr></table>