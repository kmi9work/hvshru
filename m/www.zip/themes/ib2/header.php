<table width="100%" border="0" cellpadding="0" cellspacing="0" class="border"><tr><td>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" class="logostrip"><tr>
	<td valign="top">
	  <a href="http://www.siteman.alfaspace.net/">
	  <img src="./themes/ib2/images/logo.gif" alt="Siteman CMS Russia" width="200" height="68" border="0" style="vertical-align:top" /></a>
	</td>
	<td width="100%" align="center">&nbsp;</td>
  </tr></table>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" class="submenu"><tr>
	<td><p class="navleft">&nbsp;</p></td>
	<td><p class="navright"><?php (($Siteman->settings['multi_lang']) ? $Siteman->load_lang_list() : ''); ?></p></td>
  </tr></table>
</td></tr></table>
<br />
<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr>
  <td valign="top" bgcolor="#eeeeee"><img src="./themes/ib2/images/pixel.gif" width="170" height="1" alt="" border="0" /><br />
	<table border="0" width="100%" cellspacing="0" cellpadding="0" class="border"><tr><td>
	  <table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
		<td class="blocktitle">
		  <img src="./themes/ib2/images/nav_m.gif" width="8" height="8" border="0" alt="" />&nbsp;����
		</td>
	  </tr></table>
	  <table border="0" width="100%" cellspacing="2" cellpadding="2" class="blocktext"><tr>
		<td>
		  <table width="100%" cellspacing="0" cellpadding="2"><tr>
		    <td class="menu">
			  <?php $Siteman->show_menu(); ?>
			</td>
		  </tr></table>
		</td>
	  </tr></table>
	</td>
  </tr></table>
  <br />
  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="border"><tr>
	<td>
	  <table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
		<td class="blocktitle">
		  <img src="./themes/ib2/images/nav_m.gif" width="8" height="8" border="0" alt="" />&nbsp;����������
		</td>
	  </tr></table>
	  <table border="0" width="100%" cellspacing="2" cellpadding="2" class="blocktext"><tr>
		<td><br />
		  <?php online(); ?><br />
		</td>
	  </tr></table>
	</td>
  </tr></table>
  <br />
  <table border="0" width="100%" cellspacing="0" cellpadding="0" class="border"><tr>
	<td>
	  <table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
		<td class="blocktitle">
		  <img src="./themes/ib2/images/nav_m.gif" width="8" height="8" border="0" alt="" />&nbsp;��������� �������
		</td>
	  </tr></table>
	  <table border="0" width="100%" cellspacing="2" cellpadding="2" class="blocktext"><tr>
		<td><br />
		  <?php echo lastnews(); ?>
		  <br />
		</td>
	  </tr></table>
	</td>
  </tr></table>
  <br />
</td>
<td valign="top"><img src="./themes/ib2/images/pixel.gif" width="10" height="1" alt="" /></td>
<td width="100%" valign="top"><img src="./themes/ib2/images/pixel.gif" width="1" height="1" alt="" /><br />
  <table border="0" width="100%" cellspacing="0" cellpadding="0"  class="border"><tr>
	<td>
	  <table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
		<td class="blocktitle">
		  <img src="./themes/ib2/images/nav_m.gif" width="8" height="8" border="0" alt="" />&nbsp;<?php echo $Siteman->content; ?>
		</td>
	  </tr></table>
	<table border="0" width="100%" cellspacing="5" cellpadding="5" class="blocktext"><tr><td>
	<!-- content start -->