<?php
include("txtSQL.class.php");
$db = new txtSQL("db");
$db->connect("root","");
$theme_single = 0;

if ($db->db_exists("siteman")) {
	$db->selectdb("siteman");
	include("siteman.class.php");
	include("./modules/news/last.php");
	include("./modules/users/online.php");
	$Siteman = new Website("2.0.x2 Rus");
	if ($Siteman->settings['multi_lang']) {
		if (isset($_GET['lang'])) { $Siteman->cookie('siteman_lang',trim(stripslashes(strip_tags(substr($_GET['lang'],0,2)))),time()+604800); }
	}
	if (isset($_GET["module"])) {
		$Siteman->settings["module"] = $_GET["module"];
	}
	$modulesettings = $db->select(array("table" => "modules","db" => "siteman","where" => array("name = ".$Siteman->settings["module"])));
	if (strlen($modulesettings[0]["name"]) < 1) {
		$Siteman->settings['module'] = 'pages';
	}
	$Siteman->content = $modulesettings[0]["title"];
	if ($Siteman->userinfo["level"] >= $modulesettings[0]["level"]) {
		if (file_exists("modules/".$Siteman->settings["module"]."/init.php")) {
			include("modules/".$Siteman->settings["module"]."/init.php");
		}
	}
	echo'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset='.$Siteman->settings["charset"].'" />
	<title>'.$Siteman->settings["sitename"].' -> '.$Siteman->content.'</title>
	<meta name="description" content="'.$Siteman->settings["site_description"].'" />
	<meta http-equiv="description" content="'.$Siteman->settings["site_description"].'" />
	<meta name="keywords" content="'.$Siteman->settings["site_keywords"].'" />
	<meta http-equiv="keywords" content="'.$Siteman->settings["site_keywords"].'" />
	<meta http-equiv="Cache-Control" content="private" />
	<meta name="Resource-type" content="document" />
	<meta name="document-state" content="dynamic" />
	<meta name="Robots" content="index,follow" />
	<link rel="stylesheet" type="text/css" href="themes/';
	if (file_exists("themes/".$Siteman->settings["theme"]."/style.css")) {
		echo $Siteman->settings["theme"];
	}
	else {
		echo "standard";
	}
	echo'/style.css" />';
	if (isset($reloadtime)){
		$shoutname = $_SERVER['PHP_SELF'].'?module='.$Siteman->settings["module"];
		echo '<meta http-equiv="refresh" content="'.$reloadtime.',url='.$shoutname.'">';
	}
	echo '</head>
	<body>';
	include("themes/".$Siteman->settings["theme"]."/header.php");

	if ($Siteman->userinfo["level"] >= $modulesettings[0]["level"]) {
		include("modules/".$Siteman->settings["module"]."/index.php");
	}

	include("themes/".$Siteman->settings["theme"]."/footer.php");
	echo"</body></html>";
}
else {
	include("ins.inc");		
}

$db->disconnect();
?>