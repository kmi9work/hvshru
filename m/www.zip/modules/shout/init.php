<?php
function Badwordcutter($text) {
	global $db;
	$badwords = $db->select(array("table" => "badwords","db" => "siteman"));
	foreach($badwords as $badword) {
		$text = str_replace($badword["word"],$badword["good"],strtolower($text));
	}
	return $text;
}

function global_replace($st) {
	$st = htmlspecialchars($st, ENT_QUOTES);
	$st = stripslashes($st);
	$st = str_replace("\t","",$st);
	$st = str_replace("\r","",$st);
	$st = str_replace("&nbsp;", " ", $st);
	return $st;
}
$sets = $db->select(array("table" => "shoutset","db" => "modules"));
$break = $sets[0]["break"];
$breakn = $sets[0]["breakn"];
$limit = $sets[0]["limit"];
$width = $sets[0]["width"];
$align = $sets[0]["align"];
$spamm = $sets[0]["spamm"];
$reloadtime = $sets[0]["reload"];
if($_POST['name'] !== "" && $_POST['send'] == 1 && $_POST['post'] !== "") {
    $shouted = $db->select(array("table" => "shout", "db" => "modules", "select" => array("id","ip","time"),"where" => array("ip = ".$_SERVER['REMOTE_ADDR']),"orderby" => array("id",DESC)));
	if (strlen($shouted[0]["time"]) == 10) {
		$difference = time()-$shouted[0]["time"];
		if ($difference < 10) {
			header("Location: index.php?module=shout&spammtime=1");
			$spammtime = 1;
		}
	}
    if(!isset($spammtime)) {
        $textbad = global_replace($_POST["post"]);
		$text = Badwordcutter($textbad);
		$namebad = global_replace($_POST["name"]);
		$name = Badwordcutter($namebad);
		$time = time();
        $db->insert(array("table" => "shout","db" => "modules","values" => array("username" => $name,
					"nachricht" => $text,
					"time" => $time,
					"ip" => $_SERVER['REMOTE_ADDR'])));
    
    }
}
?>