<?php
if ($more == 1) {
	$limit = $sets[0]["limit2"];
}
function smiliehtml($text) {
	$text = str_replace(':)','<img src="./public/images/smilies/orangesmile.gif" border="0">',$text);
	$text = str_replace(':(','<img src="./public/images/smilies/orangesad.gif" border="0">',$text);
    $text = str_replace(':dead:','<img src="./public/images/smilies/orangedead.gif" border="0">',$text);
	$text = str_replace(';)','<img src="./public/images/smilies/orangesmilewinkgrin.gif" border="0">',$text);
	$text = str_replace(':cry:','<img src="./public/images/smilies/orangecry.gif" border="0">',$text);
	$text = str_replace(':laugh:','<img src="./public/images/smilies/orangelaugh.gif" border="0">',$text);
	$text = str_replace(':eek:','<img src="./public/images/smilies/orangebigeek.gif" border="0">',$text);
	$text = str_replace(':confused:','<img src="./public/images/smilies/orangeconfusedw.gif" border="0">',$text);
	$text = str_replace(':mad:','<img src="./public/images/smilies/orangemad.gif" border="0">',$text);
	$text = str_replace(':motz:','<img src="./public/images/smilies/orangemotz.gif" border="0">',$text);
	$text = str_replace(':rolleyes:','<img src="./public/images/smilies/orangerolleyes.gif" border="0">',$text);
    $text = str_replace(':sigh:','<img src="./public/images/smilies/orangesighw.gif" border="0">',$text);
	$text = str_replace(':yes:','<img src="./public/images/smilies/orangeyes.gif" border="0">',$text);
	$text = str_replace(':no:','<img src="./public/images/smilies/orangeno.gif" border="0">',$text);
	$text = str_replace(':sleep:','<img src="./public/images/smilies/orangesleepw.gif" border="0">',$text);
	$text = str_replace(':upset:','<img src="./public/images/smilies/orangeupsetw.gif" border="0">',$text);
	$text = str_replace(':shy:','<img src="./public/images/smilies/orangeshy.gif" border="0">',$text);
	$text = str_replace(':look:','<img src="./public/images/smilies/orangenone.gif" border="0">',$text);
    $text = str_replace('b)','<img src="./public/images/smilies/orangecool.gif" border="0">',$text);
	$text = str_replace(':p','<img src="./public/images/smilies/orangebigrazz.gif" border="0">',$text);
	$text = str_replace(':d','<img src="./public/images/smilies/orangebiggrin.gif" border="0">',$text);
	return $text;
}
function bb_replace($st) {
	$st = str_replace("\n","<br />",$st);
	$st = str_replace("[b]","<b>",$st);
	$st = str_replace("[/b]","</b>",$st);
	$st = str_replace("[i]","<i>",$st);
	$st = str_replace("[/i]","</i>",$st);
	$st = str_replace("[u]","<u>",$st);
	$st = str_replace("[/u]","</u>",$st);
	return $st;
}
?>
<script language="JavaScript">
<!--//
	function x() { return; }
	function insertEmoticon(addSmilie) {
		var addSmilie; var revisedMessage;
		var currentMessage = document.sbx.post.value;
		revisedMessage = currentMessage+addSmilie;
		document.sbx.post.value=revisedMessage;
		document.sbx.post.focus();
	}
//-->
</script>
<table border="0" width="<?php echo $width; ?>" align="<?php echo $align; ?>" style="border-width:1px; border-style:solid; border-color:black;">
<tr><td style="border-width:1px; border-style:solid; border-color:black; size:1;" colspan="2">
<?php
if(isset($spammtime)) {
	echo '����!<br />';
}
$shoutcount = $db->table_count("shout","modules");
$start = $shoutcount - $limit;
if ($start < 0) {
	$start = 0;
}
$end = $shoutcount;
$shouted = $db->select(array("table" => "shout","db" => "modules","limit" => array($start,$end),"orderby" => array("id",DESC)));
foreach ($shouted as $shouts) {
	$datum = date($Siteman->settings['long_dateformat'],$shouts['time']+$Siteman->settings['timezone_offset']);
	$string =  wordwrap($shouts['nachricht'],$break,"<br />",1);
	$nbreak = wordwrap($shouts['username'],$breakn,"-<br />",1);
	$string = smiliehtml(bb_replace($string));
	$nbreak = bb_replace($nbreak);
	echo "<i>$datum </i>";
	echo "<b>$nbreak: </b>";
	echo $string;
	echo "<br />";
}
?>
</td></tr>
<tr><td align="center" style="border-width:1px; border-style:solid; border-color:black;" colspan=2>
<?php
if ($more == 0 || !isset($more)) {?>
<a href="index.php?module=shout&more=1">[���������� ���������]</a>
<? } ?>
</td></tr>
<tr><td colspan=2>
<table><tr align="center" valign="bottom">
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':)');" ><img src='./public/images/smilies/orangesmile.gif' alt=':)' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':(');"><img src='./public/images/smilies/orangesad.gif' alt=':(' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(';)');" ><img src='./public/images/smilies/orangesmilewinkgrin.gif' alt=';)' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon('B)');" ><img src='./public/images/smilies/orangecool.gif' alt='B)' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':D');" ><img src='./public/images/smilies/orangebiggrin.gif' alt=':D' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':P');" ><img src='./public/images/smilies/orangebigrazz.gif' alt=':P' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':cry:');" ><img src='./public/images/smilies/orangecry.gif' alt=':cry:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':dead:');" ><img src='./public/images/smilies/orangedead.gif' alt=':dead:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':laugh:');" ><img src='./public/images/smilies/orangelaugh.gif' alt=':laugh:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':eek:');" ><img src='./public/images/smilies/orangebigeek.gif' alt=':eek:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':rolleyes:');" ><img src='./public/images/smilies/orangerolleyes.gif' alt=':rolleyes:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':mad:');" ><img src='./public/images/smilies/orangemad.gif' alt=':mad:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':confused:');" ><img src='./public/images/smilies/orangeconfusedw.gif' alt=':confused:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':motz:');" ><img src='./public/images/smilies/orangemotz.gif' alt='motz' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':sigh:');" ><img src='./public/images/smilies/orangesighw.gif' alt=':sigh:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':yes:');" ><img src='./public/images/smilies/orangeyes.gif' alt=':yes:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':no:');" ><img src='./public/images/smilies/orangeno.gif' alt=':no:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':sleep:');" ><img src='./public/images/smilies/orangesleepw.gif' alt=':sleep:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':upset:');" ><img src='./public/images/smilies/orangeupsetw.gif' alt=':upset:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':shy:');" ><img src='./public/images/smilies/orangeshy.gif' alt=':shy:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':look:');" ><img src='./public/images/smilies/orangenone.gif' alt=':look:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':wink:');" ><img src='./public/images/smilies/orange21.gif' alt='wink' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':friend:');" ><img src='./public/images/smilies/orange22.gif' alt='friend' border="0"></a></td>
  	<td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':inlove:');" ><img src='./public/images/smilies/orangeinlove.gif' alt=':inlove:' border="0"></a></td>
    <td width="10%"><a href="javascript:x();" onClick="insertEmoticon(':devil:');" ><img src='./public/images/smilies/orangedevil.gif' alt='devil' border="0"></a></td>
</tr></table>
</td></tr>
<form action="./index.php?module=shout" method="post" name="sbx">
<tr><td style="border-width:1px; border-style:solid; border-color:black;">���:</td>
<td style="border-width:1px; border-style:solid; border-color:black;">
<input type="text" name="name" size="20" maxlength="20" value="<?php echo $Siteman->userinfo["username"]; ?>" />
</td></tr>
<tr><td style="border-width:1px; border-style:solid; border-color:black;">�����:</td>
<td style="border-width:1px; border-style:solid; border-color:black;" >
<input type="text" name="post" size="80" maxlength="150"/>
</td></tr>
<input type="hidden" name="send" value="1" />
<tr><td colspan=2 align="center" style="border-width:1px; border-style:solid; border-color:black;">
<input type="submit" value="���������" />
</td></tr>
</form></table>