<?php
  if ($Siteman->userinfo["level"] >= 4) {
		
		if (isset($_GET["mdo"])) {
			$mdo = $_GET["mdo"];
		}
		else {
			$mdo = "default";
		}
	
		switch ($mdo) {
		
			case "save":
				$db->update(array("table" => "shoutset","db" => "modules","where" => array("id = 1"),"values" => array("width" => $_POST["i_width"],
		"break" => $_POST["i_break"],
		"breakn" => $_POST["i_breakn"],
		"align" => $_POST["i_align"],
		"spamm" => $_POST["i_spamm"],
		"limit" => $_POST["i_limit"],
    "limit2" => $_POST["i_limit2"],
		"reload" => $_POST["i_reload"])));
    $status = "settings saved";
			break 1;
			
			case "delete":
					$db->delete(array("db" => "modules","table" => "shout")); 
					$db->insert(array("db" => "modules", "table" => "shout","values" => array("username" => "server",
		"nachricht" => "Shoutbox cleared by ADMIN!",
		"time" => time(),
		"ip" => $_SERVER["REMOTE_ADDR"])));
				$status = "deletetd";
			break 1;

		}
	
	}
?>