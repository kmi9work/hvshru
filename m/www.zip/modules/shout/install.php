 <?php
  if (substr_count($_SERVER["SCRIPT_FILENAME"],"install.php")) {
    exit("You are not allowed to access this file directly.");
  }
  switch ($mode) {
    case "install":
					$iddef = array("type" => "int","auto_increment" => 1,"primary" => 1,"permanent" => 1);
					$int = array("type" => "int");
					$string = array("type" => "string");
				  $text = array("type" => "text");
					$date = array("type" => "date");
					$time = time();
         if ($db->db_exists("modules") == "1") {
	echo '<br>Datenbank f�r "modules" existiert schon, ist aber <b>kein</b> Problem!<br />';
	} else {
                 $db->createdb(array("db" => "modules"));
         }
	$db->selectdb("modules");
	$db->createtable(array("table" => "shout","columns" => array("id" => $iddef,
		"username" => $string,
		"nachricht" => $text,
		"time" => $int,
    "ip" => $string)));
  $db->insert(array("table" => "shout","values" => array("username" => "server",
		"nachricht" => "Shoutbox installed!",
		"time" => $time,
		"ip" => $REMOTE_ADDR)));
  $db->createtable(array("table" => "shoutset","columns" => array("id" => $iddef,
		"width" => $int,
		"break" => $int,
		"breakn" => $int,
		"align" => $string,
		"spamm" => $int,
		"limit" => $int,
    "limit2" => $int,
		"reload" => $int)));    
    $db->insert(array("table" => "shoutset","values" => array("id" => 1,
		"width" => 200,
		"break" => 30,
		"breakn" => 20,
		"align" => center,
		"spamm" => 30,
		"limit" => 5,
    "limit2" => 20,
		"reload" => 60)));
		echo "Database <b>SHOUT</b> created<br />";	
    break 1;

    case "uninstall":
      	$db->droptable(array('db' => 'modules', 'table' => 'shout'));    
		$db->droptable(array('db' => 'modules', 'table' => 'shoutset')); 	
    break 1;
  }
?>