<?php
if ($Siteman->userinfo["level"] >= 4) {
	if (!isset($status)) {
		$status = "������ �� �������";
	}
	switch ($mdo) {
       default:
            $sets = $db->select(array("table" => "shoutset","db" => "modules"));
            echo "<b>Shoutbox settings:</b><br />
			<form action=\"admin.php?module=shout&amp;mdo=save\" method=\"post\">
			<table><tr><td>width:</td><td><input type=\"text\" name=\"i_width\" size=\"10\" value=\"".$sets[0]["width"]."\" /></td>
			<td>width from the shoutbox</td></tr>
			<tr><td>break:</td><td><input type=\"text\" name=\"i_break\" size=\"10\" value=\"".$sets[0]["break"]."\" /></td>
			<td>wordbreak</td></tr>
			<tr><td>breakn:</td><td><input type=\"text\" name=\"i_breakn\" size=\"10\" value=\"".$sets[0]["breakn"]."\" /></td>
			<td>namebreak</td></tr>
			<tr><td>align:</td><td><input type=\"text\" name=\"i_align\" size=\"10\" value=\"".$sets[0]["align"]."\" /></td>
			<td>shoutbox-table align</td></tr>
			<tr><td>spamm:</td><td><input type=\"text\" name=\"i_spamm\" size=\"10\" value=\"".$sets[0]["spamm"]."\" /></td>
			<td>time for spamm in seconds</td></tr>
			<tr><td>limit:</td><td><input type=\"text\" name=\"i_limit\" size=\"10\" value=\"".$sets[0]["limit"]."\" /></td>
			<td>postlimit normal</td></tr>
			<tr><td>more limit:</td><td><input type=\"text\" name=\"i_limit2\" size=\"10\" value=\"".$sets[0]["limit2"]."\" /></td>
			<td>postlimit for more</td></tr>
			<tr><td>reload :</td><td><input type=\"text\" name=\"i_reload\" size=\"10\" value=\"".$sets[0]["reload"]."\" /></td>
			<td>sec., refreshtime for page</td></tr>
			<tr><td colspan=2 align=center><input type=\"submit\" value=\"���������\" /></td><td>&nbsp;</td></tr></table></form><br />
			<br /><a href=\"admin.php?module=shout&amp;mdo=delete\">delete shouts</a>";
       break 1;
	}
	echo "<br /><div align=center>������: ". $status;
	echo "<hr width=80%>Shoubox-Modul for siteman2. Version: 1.0.6.08<br />written 2005 by <i>cyber</i>wulf<br /></div>";
}
?>