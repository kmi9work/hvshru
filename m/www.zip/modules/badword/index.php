<?php
	echo "This module have only <b>admin</b>-functions<br />";
?>