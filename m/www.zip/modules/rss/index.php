<?php
// include lastRSS
include "./modules/rss/lastRSS.php";
// Create lastRSS object
$rss = new lastRSS;
// Set cache dir and cache time limit (1200 seconds)
// (don't forget to chmod cahce dir to 777 to allow writing)
$rss->cache_dir = './temp';
$rss->cache_time = 1200;
// Try to load and parse RSS file
$sm_rss = $db->select(array("table" => "rss","db" => "siteman"));
if ($rs = $rss->get($sm_rss[0]["rss_url"])) {
    // Show website logo (if presented)
    if ($rs[image_url] != '' && $sm_rss[0]["display_image"] != 0) {
        echo "<a href=\"$rs[image_link]\"><img src=\"$rs[image_url]\" alt=\"$rs[image_title]\" vspace=\"1\" border=\"0\" /></a><br />\n";
	}
    // Show clickable website title
    if ($rs[title] != '' && $sm_rss[0]["display_title"] != 0) {
		echo "<big><b><a href=\"$rs[link]\">$rs[title]</a></b></big><br />\n";
	}
    // Show website description
    if ($rs[description] != '' && $sm_rss[0]["display_desc"] != 0) {
	   echo "$rs[description]<br />\n";
    }
    // Show last published articles (title, link, description)
    echo "<font size=-2><ul>\n";
    foreach($rs['items'] as $item) {
		// echo "\t<li><a href=\"$item[link]\">".$item['title']."</a><br />".$item['description']."</li>\n";
        echo "\t<li><a href=\"$item[link]\">".$item['title']."</a>";
		$string = $item["description"];
		$string = str_replace ( '&#38;', '&', $string );
		$string = str_replace ( '&#039;', '\'', $string );
		$string = str_replace ( '&#34;', '"', $string );
		$string = str_replace ( '&#60;', '<', $string );
		$string = str_replace ( '&#62;', '>', $string );
		$string = str_replace ( 'a href', 'a target=_blank href', $string );
		echo $string;
		echo "</li><br />\n";
	}
	echo "</ul></font>\n";
}
else {
    echo "������: ���������� ����������� � RSS-������...\n";
}
?>