<?php
$data = $db->select(array("table" => "rss","db" => "siteman","where" => array("id = 1")));
$info = $data[0];
$Siteman->content = $info["rss_name"];
?>