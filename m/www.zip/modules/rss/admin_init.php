<?php
if ($Siteman->userinfo["level"] >= 4) {
	if (isset($_GET["mdo"])) {
		$mdo = $_GET["mdo"];
	}
	else {
		$mdo = "default";
	}
	switch ($mdo) {

		case "save":
			$sm_rss = $db->select(array("table" => "rss","db" => "siteman","where" => array("id = 1")));
			$db->update(array("table" => "rss","db" => "siteman","where" => array("id = 1"),"values" => array("rss_name" => stripslashes($_POST["i_rss_name"]),"rss_url" => $_POST["i_rss_url"],"display_image" => $_POST["i_display_image"],"display_title" => $_POST["i_display_title"],"display_desc" => $_POST["i_display_desc"],"font_size" => $_POST["i_font_size"])));
			$rss_status = "���������� ������...";
			header("Location: admin.php?module=rss&rss_status=".$rss_status);
		break 1;

	}
}
?>