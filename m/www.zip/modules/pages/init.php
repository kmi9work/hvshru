<?php
if (isset($_GET["page"])) {
	$page = $_GET["page"];
}
else {
	$page = "index";
}
$data = $db->select(array("table" => "pages","db" => "siteman","where" => array("name = $page")));
$info = $data[0];
$Siteman->content = $info["title"];
?>