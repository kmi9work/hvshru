<?php
if ($Siteman->userinfo["level"] >= $info["level"]) {
	$content = $db->select(array("table" => $page,"db" => "pages"));
	$clicks = $db->select(array("table" => "pages_clicks","db" => "siteman","where" => array("name = $page")));
	$clicks[0]["clicks"]++;
	$db->update(array("table" => "pages_clicks","db" => "siteman","where" => array("name = $page"),"values" => array("clicks" => $clicks[0]["clicks"])));
	echo $content[0]["content"];
}
else {
$Siteman->load_lang("forums");
echo $Siteman->lang["viewlevel"];
}
?>