<?php
if ($Siteman->userinfo["level"] >= 4) {
	if (isset($_GET["mdo"])) {
		$mdo = $_GET["mdo"];
	}
	else {
		$mdo = "default";
	}

	switch ($mdo) {

		case "save":
			if (($page = $db->select(array("table" => "pages","db" => "siteman","where" => array("name = ".$_GET["page"])))) !== FALSE) {
				if ($Siteman->userinfo["id"] == $page[0]["owner"] || $Siteman->userinfo["level"] == 5) {
					if (isset($_POST["content"])) {
						if (substr_count(stripslashes($_POST["content"]),"<!-- REMOVE -->") > 0) {
							$contentarray = explode("<!-- REMOVE -->",stripslashes($_POST["content"]));
							$count = (substr_count(stripslashes($_POST["content"]),"<!-- REMOVE -->"))/2;
							$content = $contentarray[$count];
						}
						else {
							$content = stripslashes($_POST["content"]);
						}
						$db->update(array("table" => $_GET["page"],"db" => "pages","where" => array("id = 1"),"values" => array("content" => $content)));
						$db->update(array("db" => "siteman","table" => "pages","where" => array("name = ".$_GET["page"]),"values" => array("title" => stripslashes($_POST["title"]),"level" => $_POST["level"],"keywords" => stripslashes($_POST["keywords"]),"last_edited" => time())));
						if ($_POST["save"] == "���������") {
							header("Location: admin.php?module=pages&mdo=editpage&page=".$_GET["page"]);
							exit;
						}
						else {
							header("Location: admin.php?module=pages");
							exit;
						}
					}
				}
			}
		break 1;

		case "create":
			if ($Siteman->userinfo["level"] >= 4) {
				$name = stripslashes($_POST["name"]);
				$page = $db->select(array("table" => "pages","db" => "siteman","where" => array("name = $name")));
				if (strlen($page[0]["name"]) == 0) {
					$db->insert(array("table" => "pages","db" => "siteman","values" => array("name" => $name,"owner" => $Siteman->userinfo["id"],"level" => 1,"title" => "","keywords" => "","last_edited" => time())));
					$db->insert(array("table" => "pages_clicks","db" => "siteman","values" => array("name" => $name)));
					$db->createtable(array("db" => "pages","table" => $name,"columns" => array("content" => array("type" => "text"),"id" => array("type" => "int","default" => 1))));
					$db->insert(array("db" => "pages","table" => $name,"values" => array("content" => "")));
				}
				header("Location: admin.php?module=pages&mdo=editpage&page=".$name);
				exit;
			}
		break 1;

		case "dodelpage":
			$page = $_GET["page"];
			$pageinfo = $db->select(array("table" => "pages","db" => "siteman","where" => array("name = $page")));
			$owner = $db->select(array("table" => "users","db" => "siteman","where" => array("id = ".$pageinfo[0]["owner"])));
			if ($Siteman->userinfo["level"] > $owner[0]["level"] || $Siteman->userinfo["id"] == $owner[0]["id"]) {
				if ($page != "index") {
					$db->delete(array("table" => "pages","db" => "siteman","where" => array("name = $page")));
					$db->delete(array("table" => "pages_clicks","db" => "siteman","where" => array("name = $page")));
					$db->droptable(array("table" => $page,"db" => "pages"));
					header("Location: admin.php?module=pages");
					exit;
				}
			}
		break 1;

		case "rcc":
			$page = $_GET["page"];
			$pageinfo = $db->select(array("table" => "pages","db" => "siteman","where" => array("name = $page")));
			$owner = $db->select(array("table" => "users","db" => "siteman","where" => array("id = ".$pageinfo[0]["owner"])));
			if ($Siteman->userinfo["level"] > $owner[0]["level"] || $Siteman->userinfo["id"] == $owner[0]["id"]) {
				$db->update(array("table" => "pages_clicks","db" => "siteman","where" => array("name = $page"),"values" => array("clicks" => 0)));
			}
		break 1;

		case "editpage":
			$nav_links .= "<b> >> �������������� ��������</b>";
		break 1;
			
		case "delpage":
			$nav_links .= "<b> >> �������� ��������</b>";
		break 1;

	}
}
?>