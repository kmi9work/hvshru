<html><head><title>���� ������</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
</head>
<body>
<table border="0" cellspacing="0" cellPadding="2" width="250" align="center">
<tr>
<td class="tablecontent" style="background-color:white;">
<table border="0">
<tr><td><b>����</b></td><td><b>���</b></td></tr>
<tr><td>Afar 	</td><td>aa </td></tr>
<tr><td>Abkhazian 	</td><td>ab </td></tr>
<tr><td>Afrikaans 	</td><td>af </td></tr>
<tr><td>Amharic  	</td><td>am </td></tr>
<tr><td>Arabic   	</td><td>ar </td></tr>
<tr><td>Assamese 	</td><td>as </td></tr>
<tr><td>Aymara  	</td><td>ay </td></tr>
<tr><td>Azerbaijani   	</td><td>az  </td></tr>
<tr><td>Bashkir   	</td><td>ba </td></tr>
<tr><td>Byelorussian   	</td><td>be  </td></tr>
<tr><td>Bulgarian  	</td><td>bg  </td></tr>
<tr><td>Bihari  	</td><td>bh </td></tr>
<tr><td>Bislama 	</td><td>bi </td></tr>
<tr><td>Bengali; Bangla 	</td><td>bn  </td></tr>
<tr><td>Tibetan 	</td><td>bo </td></tr>
<tr><td>Breton 	</td><td>br </td></tr>
<tr><td>Catalan   	</td><td>ca </td></tr>
<tr><td>Corsican 	</td><td>co  </td></tr>
<tr><td>Czech   	</td><td>cs </td></tr>
<tr><td>Welsh 	</td><td>cy </td></tr>
<tr><td>Danish   	</td><td>da  </td></tr>
<tr><td>german  	</td><td>de </td></tr>
<tr><td>bhutani  	</td><td>dz </td></tr>
<tr><td>greek   	</td><td>el </td></tr>
<tr><td>english  	</td><td>   en </td></tr>
<tr><td>esperanto 	</td><td>  eo  </td></tr>
<tr><td>spanish  	</td><td>   es </td></tr>
<tr><td>estonian  	</td><td>  et </td></tr>
<tr><td>basque   	</td><td>   eu </td></tr>
<tr><td>persian 		</td><td>fa  </td></tr>
<tr><td>finnish  	</td><td>   fi </td></tr>
<tr><td>fiji  	</td><td>   fj </td></tr>
<tr><td>faroese  	</td><td>   fo </td></tr>
<tr><td>french   	</td><td>   fr</td></tr>
<tr><td>frisian   	</td><td>  fy </td></tr>
<tr><td>irish  	</td><td>  ga</td></tr>
<tr><td>scots gaelic  	</td><td>  gd</td></tr>
<tr><td>galician  	</td><td>  gl</td></tr>
<tr><td>guarani   	</td><td>  gn </td></tr>
<tr><td>gujarati 	</td><td>   gu </td></tr>
<tr><td>hausa 	</td><td>   ha </td></tr>
<tr><td>hebrew   	</td><td>   he </td></tr>
<tr><td>hindi 	</td><td>   hi </td></tr>
<tr><td>croatian 	</td><td>   hr </td></tr>
<tr><td>hungarian 	</td><td>   hu </td></tr>
<tr><td>armenian 	</td><td>   hy   </td></tr>
<tr><td>interlingua   	</td><td>  ia </td></tr>
<tr><td>interlingue  	</td><td>   ie  </td></tr>
<tr><td>inupiak  	</td><td>   ik  </td></tr>
<tr><td>indonesian 	</td><td>  id  </td></tr>
<tr><td>icelandic 	</td><td>  is  </td></tr>
<tr><td>italian  	</td><td>   it </td></tr>
<tr><td>inuktitut 	</td><td>   iu </td></tr>
<tr><td>japanese 	</td><td>   ja </td></tr>
<tr><td>javanese 	</td><td>   jv </td></tr>
<tr><td>georgian 	</td><td>   ka </td></tr>
<tr><td>kazakh 	</td><td>  kk </td></tr>
<tr><td>greenlandic   	</td><td>  kl </td></tr>
<tr><td>cambodian 	</td><td>  km </td></tr>
<tr><td>kannada  	</td><td>   kn </td></tr>
<tr><td>korean   	</td><td>   ko </td></tr>
<tr><td>kashmiri 	</td><td>   ks </td></tr>
<tr><td>kurdish  	</td><td>   ku </td></tr>
<tr><td>kirghiz  	</td><td>   ky </td></tr>
<tr><td>latin 	</td><td>   la </td></tr>
<tr><td>lingala   	</td><td>  ln </td></tr>
<tr><td>laothian  	</td><td>  lo </td></tr>
<tr><td>lithuanian 	</td><td> lt </td></tr>
<tr><td>latvian;lettish	</td><td> lv </td></tr>
<tr><td>malagasy  	</td><td>  mg </td></tr>
<tr><td>maori  	</td><td>  mi </td></tr>
<tr><td>macedonian 	</td><td>  mk  </td></tr>
<tr><td>malayalam 	</td><td>  ml  </td></tr>
<tr><td>mongolian 	</td><td>  mn </td></tr>
<tr><td>moldavian 	</td><td>  mo </td></tr>
<tr><td>marathi   	</td><td>  mr </td></tr>
<tr><td>malay  	</td><td>  ms </td></tr>
<tr><td>maltese   	</td><td>  mt </td></tr>
<tr><td>burmese   	</td><td>  my </td></tr>
<tr><td>nauru  	</td><td>  na </td></tr>
<tr><td>nepali 	</td><td>  ne </td></tr>
<tr><td>dutch  	</td><td>  nl </td></tr>
<tr><td>norwegian 	</td><td>  no  </td></tr>
<tr><td>occitan   	</td><td>  oc </td></tr>
<tr><td>afan (oromo)  	</td><td>  om  </td></tr>
<tr><td>oriya  	</td><td>  or   </td></tr>
<tr><td>punjabi   	</td><td>  pa  </td></tr>
<tr><td>polish 	</td><td>  pl </td></tr>
<tr><td>pashto;pushto 	</td><td>  ps  </td></tr>
<tr><td>portuguese 	</td><td> pt </td></tr>
<tr><td>quechua 	</td><td> qu  </td></tr>
<tr><td>rhaeto-romance 	</td><td> rm  </td></tr>
<tr><td>kurundi 	</td><td> rn </td></tr>
<tr><td>romanian   	</td><td> ro  </td></tr>
<tr><td>Russian 	</td><td> ru </td></tr>
<tr><td>kinyarwanda   	</td><td>  rw  </td></tr>
<tr><td>sanskrit  	</td><td>  sa  </td></tr>
<tr><td>sindhi 	</td><td>  sd  </td></tr>
<tr><td>sangho 	</td><td>  sg  </td></tr>
<tr><td>serbo-croatian 	</td><td> sh </td></tr>
<tr><td>singhalese 	</td><td> si  </td></tr>
<tr><td>slovak  	</td><td> sk  </td></tr>
<tr><td>slovenian  	</td><td> sl </td></tr>
<tr><td>samoan  	</td><td> sm </td></tr>
<tr><td>shona  	</td><td>  sn </td></tr>
<tr><td>somali  	</td><td> so </td></tr>
<tr><td>albanian   	</td><td> sq </td></tr>
<tr><td>serbian 	</td><td> sr </td></tr>
<tr><td>siswati 	</td><td> ss </td></tr>
<tr><td>sesotho 	</td><td> st </td></tr>
<tr><td>sundanese 	</td><td>  su </td></tr>
<tr><td>swedish   	</td><td>  sv </td></tr>
<tr><td>swahili   	</td><td>  sw </td></tr>
<tr><td>tamil  	</td><td>  ta </td></tr>
<tr><td>telugu 	</td><td> te </td></tr>
<tr><td>tajik  	</td><td>  tg </td></tr>
<tr><td>thai   	</td><td> th </td></tr>
<tr><td>tigrinya  	</td><td>  ti </td></tr>
<tr><td>turkmen   	</td><td>  tk </td></tr>
<tr><td>tagalog   	</td><td>  tl </td></tr>
<tr><td>setswana  	</td><td>  tn </td></tr>
<tr><td>tonga  	</td><td>  to</td></tr>
<tr><td>turkish   	</td><td>  tr </td></tr>
<tr><td>tsonga 	</td><td>  ts </td></tr>
<tr><td>tatar  	</td><td>  tt </td></tr>
<tr><td>twi   	</td><td>  tw </td></tr>
<tr><td>uigur  	</td><td>  ug </td></tr>
<tr><td>Ukrainian   	</td><td>   uk </td></tr>
<tr><td>urdu  	</td><td>   ur </td></tr>
<tr><td>uzbek  	</td><td>  uz </td></tr>
<tr><td>vietnamese 	</td><td>  vi </td></tr>
<tr><td>volapuk   	</td><td>  vo  </td></tr>
<tr><td>wolof  	</td><td>  wo </td></tr>
<tr><td>xhosa  	</td><td>  xh </td></tr>
<tr><td>yiddish   	</td><td>  yi </td></tr>
<tr><td>yoruba 	</td><td>  yo </td></tr>
<tr><td>zhuang 	</td><td>  za </td></tr>
<tr><td>chinese   	</td><td>  zh </td></tr>
<tr><td>zulu   		</td><td>zu </td></tr>
</table>
<div align="center"><a href="javascript:window.close();">������� ����</a></div>
<br>	
</td>
</tr>
</table>
</body></html>