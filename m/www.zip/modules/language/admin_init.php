<?php
if ($Siteman->userinfo["level"] >= 4) {
	if (isset($_GET["mdo"])) {
		$mdo = $_GET["mdo"];
	}
	else {
		$mdo = "default";
	}
	switch ($mdo) {

		case "save":
			$langua = $db->select(array("table" => $_POST["langdb"],"db" => "language"));
			foreach ($langua as $lines) {
				$id = $lines["key"];
				$db->update(array("table" => $_POST["langdb"],"db" => "language","where" => array("key = $id"),"values" => array("phrase" => $_POST["action"][$id])));
			}
			$lang_status = "���������� ������...";
			header("Location: admin.php?module=language&lang_status=".$lang_status);
		break 1;

		case "edit":
			$lang = $db->select(array("table" => $_POST["language"],"db" => "language","orderby" => array("section",ASC)));
		break 1;

		case "create":
$db->selectdb("language");
			if ($_POST["new_lang"] == "" || $_POST["new_lang"] == "�����"){
				$lang_status = "����������, ������� ��� �����";
				break 1;
			}
			else {
				$db->createtable(array("table" => $_POST["new_lang"],"columns" => array("key" => $string,"section" => $string,"phrase" => $string)));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "username","section" => "users","phrase" => "Username")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "password","section" => "users","phrase" => "Password")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "register","section" => "users","phrase" => "Register")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "forgotpass","section" => "users","phrase" => "Forgot Password?")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "login","section" => "users","phrase" => "Log In")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "needvalidation","section" => "users","phrase" => "%users% users awaiting account validation")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "yourlevel","section" => "users","phrase" => "Your member level is %level%")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "remember","section" => "users","phrase" => "Remember Me")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "wrongpass","section" => "users","phrase" => "<span class='error'>Error: Wrong Password!</span>")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "usernotfound","section" => "users","phrase" => "<span class='error'>Error: unknown username</span>")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "notvalidated","section" => "users","phrase" => "<span class='error'>Your account has not yet been validated</span>")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "0","section" => "levels","phrase" => "Banned user")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "1","section" => "levels","phrase" => "Guest")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "1_alt","section" => "levels","phrase" => "All Users")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "2","section" => "levels","phrase" => "Member")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "3","section" => "levels","phrase" => "Author")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "4","section" => "levels","phrase" => "Admin")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "5","section" => "levels","phrase" => "Webmaster")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "logout","section" => "users","phrase" => "Log Out")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "mlist","section" => "users","phrase" => "Members list")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "myaccount","section" => "users","phrase" => "My Account")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "welcome","section" => "users","phrase" => "Welcome, %user%")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "editaccount","section" => "users","phrase" => "Change your account details.")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "oldpass","section" => "users","phrase" => "Old Password (only needed if you are going to change your password or secret answer)")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "newpass","section" => "users","phrase" => "New Password")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "rnewpass","section" => "users","phrase" => "Repeat New Password")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "email","section" => "users","phrase" => "Email adress")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "hideemail","section" => "users","phrase" => "Hide email adress from other users?")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "yes","section" => "general","phrase" => "Yes")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "no","section" => "general","phrase" => "No")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "fsign","section" => "users","phrase" => "Forum Signature, max 250 chars, <u>some</u> HTML allowed")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "squest","section" => "users","phrase" => "Secret Question (A question that only you know the answer of)")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "sans","section" => "users","phrase" => "Answer to secret question")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "repsans","section" => "users","phrase" => "Repeat answer")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "save","section" => "users","phrase" => "Save")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "nametaken","section" => "users","phrase" => "Username already taken")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "emailtaken","section" => "users","phrase" => "An account with this email adress already exists")));
				$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "invalidchar","section" => "users","phrase" => stripslashes("Username cannot contain the following characters: &lt; &gt; \" ' \\"))));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "toolong","section" => "users","phrase" => "Username cannot be longer than 40 characters")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "passnomatch","section" => "users","phrase" => "New passwords didn't match")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "wrongoldpass","section" => "users","phrase" => "Old password entered was wrong")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "invalidadress","section" => "users","phrase" => "Invalid email adress")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "sansnomatch","section" => "users","phrase" => "Answers to secret question didn't match")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "noresize","section" => "users","phrase" => "You are not allowed to change the font size in the forum signature")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "datasaved","section" => "users","phrase" => "Your Account was saved.")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "clicktoshow","section" => "users","phrase" => "Click to show...")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "rtmyaccount","section" => "users","phrase" => "Return to My Account >>")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "regnew","section" => "users","phrase" => "Register New Account")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "reguname","section" => "users","phrase" => "Username (no spaces or HTML/special characters)")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "regpass","section" => "users","phrase" => "Password (no spaces, case sensitive)")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "rpass","section" => "users","phrase" => "Repeat password")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "continue","section" => "users","phrase" => "Continue >>")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "missfields","section" => "users","phrase" => "All fields must be entered")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "error","section" => "users","phrase" => "<span class='error'>Error:</span>")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "regpassnomatch","section" => "users","phrase" => "Passwords entered didn't match")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "regstep","section" => "users","phrase" => "Register New Account: Step 2")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "invalidhtml","section" => "users","phrase" => "You are not allowed to change the font size in the forum signature")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "datarecorded","section" => "users","phrase" => "The following data was recorded:")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "arecorrect","section" => "users","phrase" => "Are these data correct?")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "regcomplete","section" => "users","phrase" => "Registration complete")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "wascompleted","section" => "users","phrase" => "Registration was completed. Please log in.")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "mustvalidate","section" => "users","phrase" => "Registration was completed. Your account must be validated by an admin before you can log in.")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "name","section" => "guestbook","phrase" => "Name")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "email","section" => "guestbook","phrase" => "Email")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "website","section" => "guestbook","phrase" => "Website")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "location","section" => "guestbook","phrase" => "Location")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "sign","section" => "guestbook","phrase" => "Sign Guestbook")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "pleasesign","section" => "guestbook","phrase" => "Please sign the guestbook! Name and text must be filled in.")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "text","section" => "guestbook","phrase" => "Text")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "thankyou","section" => "guestbook","phrase" => "Thank you for signing.")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "previous","section" => "guestbook","phrase" => "Previous posts:")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "messageposted","section" => "guestbook","phrase" => "Posted on the %date%")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "floodcontrol","section" => "guestbook","phrase" => "<b>Note</b>: Flood control restriction in effect. You cannot post less than five minutes since last time.")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "icq","section" => "guestbook","phrase" => "ICQ")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "gbreply","section" => "guestbook","phrase" => "Reply")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "textdecor","section" => "guestbook","phrase" => "Text decoration")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "bold","section" => "guestbook","phrase" => "Bold")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "italic","section" => "guestbook","phrase" => "Italic")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "underline","section" => "guestbook","phrase" => "Underline")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "newcat","section" => "forums","phrase" => "New Category")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "forumstart","section" => "forums","phrase" => "Forums index")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "forums","section" => "forums","phrase" => "Forums")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "news","section" => "forums","phrase" => "News")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "category","section" => "forums","phrase" => "Category")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "topics","section" => "forums","phrase" => "Topics")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "posts","section" => "forums","phrase" => "Posts")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "catname","section" => "forums","phrase" => "Category Name")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "catdesc","section" => "forums","phrase" => "Category Description")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "startlevel","section" => "forums","phrase" => "Level required to start topics")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "viewlevel","section" => "forums","phrase" => "Level required to view topics")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "replylevel","section" => "forums","phrase" => "Level required to reply to topics")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "nouploads","section" => "forums","phrase" => "Disable file uploads in this category")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "uploadlevel","section" => "forums","phrase" => "Level required to upload files with posts")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "maxfilesize","section" => "forums","phrase" => "Max upload filesize for guests (level 1) (in bytes)")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "max2filesize","section" => "forums","phrase" => "Max upload filesize for members (level 2)")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "max3filesize","section" => "forums","phrase" => "Max upload filesize for authors (level 3)")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "max4filesize","section" => "forums","phrase" => "Max upload filesize for admins (level 4)")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "addcat","section" => "forums","phrase" => "Add Category")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "mancats","section" => "forums","phrase" => "Manage Categories")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "edit","section" => "forums","phrase" => "Edit")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "delete","section" => "forums","phrase" => "Delete")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "editcat","section" => "forums","phrase" => "Edit Category '%cat%'")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "savecat","section" => "forums","phrase" => "Save Category")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "manfiles","section" => "forums","phrase" => "Manage Uploaded Files")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "delcat","section" => "forums","phrase" => "Delete Category '%cat%'")));
	$db->insert(array("table" => $_POST["new_lang"],"values" => array("key" => "suredelete","section" => "forums","phrase" => "Are you sure you want to delete category '%cat%'?")));	
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "news","section" => "news","phrase" => "News")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "read_more","section" => "news","phrase" => "Read more")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "pages","section" => "news","phrase" => "Pages")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "views","section" => "news","phrase" => "Views:")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "comments","section" => "news","phrase" => "Comments")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "not_news","section" => "news","phrase" => "There are no news in this category.")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "comm_in_news","section" => "news","phrase" => "Your comment to news")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "char","section" => "news","phrase" => "symbols")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "char_left","section" => "news","phrase" => "remains")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "comm_error","section" => "news","phrase" => "Only registered users can leave comments to news in this category! <a href=\"index.php?module=users\">Registration</a>")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "cat","section" => "news","phrase" => "Category")));
			$db->insert(array("table" => $_POST["new_lang"],"db" => "language","values" => array("key" => "news_archive","section" => "news","phrase" => "News archive")));
				$lang_status = "new language db created";
			}
			$langs = $db->showtables(array("db" => "language"));
		break 1;

		default:
			$langs = $db->showtables(array("db" => "language"));
		break 1;

	}
}
?>