<?php
function global_replace($st) {
	$st = htmlspecialchars($st, ENT_QUOTES);
	$st = stripslashes($st);
	$st = str_replace("\t","",$st);
	$st = str_replace("\r","",$st);
	$st = str_replace("&nbsp;", " ", $st);
	return $st;
}
$Siteman->load_lang("users");
if (isset($_GET["do"])) {
	$do = $_GET["do"];
}
if ($Siteman->loginok) {
	switch ($do) {

		case "mlist":	
		break 1;

		case "save":
			$values = array();
			$usernamerror = 0;
			$passworderror = 0;
			$emailerror = 0;
			$fsignerror = 0;
			$sanserror = 0;
			$chhideemail = 0;
			$chsquest = 0;
			if (strlen($_POST["username"]) > 0 && $_POST["username"] != $Siteman->userinfo["username"]) {
				$usernameerror = 1;
				if (strlen($_POST["username"]) >= 40) {
					if (substr_count($_POST["username"],"<") == 0 ||substr_count($_POST["username"],">") == 0 || substr_count($_POST["username"],"'") == 0 || substr_count($_POST["username"],'"') == 0 || substr_count($_POST["username"],stripslashes("\\")) == 0) {
						$usercheck[0]["joined"];
						$usercheck = $db->select(array("table" => "users","db" => "siteman","where" => array("strLower(username) = ".strtolower($_POST["username"]))));
						if ($usercheck[0]["joined"] > 0) {
							$values["username"] = global_replace($_POST["username"]);
						}
						else {
							$usernameerror = "nametaken";
						}
					}
					else {
						$usernameerror = "invalidchar";
					}
				}
				else {
					$usernameerror = "toolong";
				}
			}
			if (strlen($_POST["newpass"]) > 0) {
				$passworderror = 1;
				if (md5($_POST["oldpass"]) == $Siteman->userinfo["password"]) {
					if ($_POST["newpass"] == $_POST["rnewpass"]) {
						$values["password"] = md5($_POST["newpass"]);
					}
					else {
						$passworderror = "passnomatch";
					}
				}
				else {
					$passworderror = "wrongoldpass";
				}
			}
			if (strlen($_POST["email"]) > 0 && $_POST["email"] != $Siteman->userinfo["email"]) {
				$emailerror = 1;
				if (substr_count($_POST["email"],"@") == 1) {
					if (substr_count($_POST["email"],".") >= 1) {
						$adressbase = array_reverse(explode(".",$_POST["email"]));
						if (strlen($adressbase[0]) <= 4) {
							if (substr_count($adressbase[0],"@") == 0) {
								$values["email"] = global_replace($_POST["email"]);
							}
							else {
								$emailerror = "invalidadress";
							}
						}
						else {
							$emailerror = "invalidadress";
						}
					}
					else {
						$emailerror = "invalidadress";
					}
				}
				else {
					$emailerror = "invalidadress";
				}
			}
			if ($_POST["hide_email"] != $Siteman->userinfo["hide_email"]) {
				$chhideemail = 1;
				$values["hide_email"] = $_POST["hide_email"];
			}
			if (substr_count($_POST["forum_signature"],"<big") == 0) {
				if (substr_count($_POST["forum_signature"],"size=") == 0) {
					if (substr_count($_POST["forum_signature"],"font-size") == 0) {
						$values["forum_signature"] = global_replace(substr($_POST["forum_signature"],0,250));
					}
					else {
						$fsignerror = "noresize";
					}
				}
				else {
					$fsignerror = "noresize";
				}
			}
			else {
				$fsignerror = "noresize";
			}
			if (strlen($_POST["squest"]) > 0 && $_POST["squest"] != $Siteman->userinfo["squest"]) {
				$chsquest = 1;
				$values["squest"] = global_replace($_POST["squest"]);
			}
			if (strlen($_POST["sans"]) > 0) {
				$sanserror = 1;
				if (md5($_POST["oldpass"]) == $Siteman->userinfo["password"]) {
					if ($_POST["sans"] == $_POST["repsans"]) {
						$values["sanswer"] = md5($_POST["sans"]);
					}
					else {
						$sanserror = "sansnomatch";
					}
				}
				else {
					$sanserror = "wrongoldpass";
				}
			}
			$db->update(array("table" => "users","db" => "siteman","where" => array("id = ".$Siteman->userinfo["id"]),"values" => $values));
			if ($values["password"] == md5($_POST["newpass"])) {
				$ident = $Siteman->settings["identifier"];
				$cookiedata = explode(":",$_COOKIE[$ident]);
				$Siteman->login($Siteman->userinfo["id"],"",$_POST["newpass"],$cookiedata[2]);
			}
		break 1;

		default:
			$Siteman->content = $Siteman->lang["myaccount"];
		break 1;

	}
}
else {
	switch ($do) {

	case "regstep":
		$Siteman->content = $Siteman->lang["regstep"];
	break 1;

	case "regcomplete":
		if (strlen($_POST["username"]) > 0 && strlen($_POST["password"]) > 0 && strlen($_POST["email"]) > 0 && strlen($_POST["squest"]) > 0 && strlen($_POST["sans"]) > 0) {
			$registered = $db->select(array("table" => "users","db" => "siteman","where" => array("strLower(username) = ".strtolower($_POST["username"]))));
			if (strlen($registered[0]["username"]) > 0) {
				exit;
			}
			else {
				$registered = $db->select(array("table" => "users","db" => "siteman","where" => array("strLower(email) = ".strtolower($_POST["email"]))));
				if (strlen($registered[0]["email"]) > 0) {
					exit;
				}
				else if (substr_count($_POST["username"],"<") == 0 && substr_count($_POST["username"],">") == 0 && substr_count($_POST["username"],"'") == 0 && substr_count($_POST["username"],'"') == 0 && substr_count($_POST["username"],stripslashes("\\")) == 0) {
					if ($Siteman->settings["user_validation"]) {
						$level = 1;
					}
					else {
						$level = 2;
					}
					$db->insert(array("table" => "users","db" => "siteman","values" => array("username" => global_replace($_POST["username"]),"password" => md5($_POST["password"]),"email" => global_replace(strtolower($_POST["email"])),"hide_email" => $_POST["hideemail"],"forum_signature" => global_replace($_POST["fsign"]),"level" => $level,"squest" => global_replace($_POST["squest"]),"sanswer" => md5($_POST["sans"]))));
					$newid = $db->last_insert_id("users","siteman","id");
					$db->insert(array("table" => "last_online","values" => array("id" => $newid,"last_online" => 0)));
					$Siteman->content = $Siteman->lang["regcomplete"];
				}
			}
		}
	break 1;

	default:
		$Siteman->content = $Siteman->lang["regnew"];
	break 1;

	}
}
?>