<?php
if ($Siteman->loginok) {
	switch ($do) {

	case "mlist":
		$userdb = $db->select(array("table" => "users","db" => "siteman","where" => array("level >= 1")));
		if ($Siteman->userinfo["level"] >= 2){
			echo "<table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"2\">
			<tr><td width=\"17\">&nbsp;</td>
			<td>���</td>
			<td align=\"center\">�������</td>
			<td align=\"center\">��������� ���������</td>
			<td>E-mail</td></tr>";
			foreach ($userdb as $usrdb){
				$lastvisit = $db->select(array("table" => "last_online","db" => "siteman","where" => array("id = ".$usrdb["id"])));
				$last = ($lastvisit[0]["last_online"] != 0) ? date($Siteman->settings["long_dateformat"],$lastvisit[0]["last_online"]+$Siteman->settings["timezone_offset"]) : "never";
				$online = ($lastvisit[0]["last_online"]+300 > time()+$Siteman->settings["timezone_offset"]) ? "<img src=\"./modules/users/img/online.gif\" width=\"16\" height=\"16\" border=\"0\">" : "&nbsp;";
				$entrycode = file("./modules/users/user.tpl");
				foreach ($entrycode as $printing) {
					$printing = str_replace("%img%",str_repeat("<img src=\"./modules/users/img/star".$usrdb["level"].".gif\" border=\"0\" width=\"11\" height=\"10\" alt=\"".$usrdb["username"]."\" />",$usrdb["level"]),$printing);
					$printing = str_replace("%user%",$usrdb["username"],$printing);							
					$printing = str_replace("%last%",$last,$printing);
					$printing = str_replace("%online%",$online,$printing);
					if ($usrdb["hide_email"] == 0) {
						$printing = str_replace("%email%",$usrdb["email"],$printing);
					}
					else {
						$printing = str_replace("%email%","�����",$printing);
					}
					echo $printing;
				}	 
			}
			echo"</table><br /><br /><table><tr><td>
			<img src=\"modules/users/img/star1.gif\" border=\"0\"  width=\"11\" height=\"10\" alt=\"�������/������� �� �������\" /> = �������/������� �� �������</td></tr>
			<tr><td>".str_repeat("<img src=\"modules/users/img/star2.gif\" border=\"0\"  width=\"11\" height=\"10\" />",2)." = ������������</td></tr>
			<tr><td>".str_repeat("<img src=\"modules/users/img/star3.gif\" border=\"0\"  width=\"11\" height=\"10\" alt=\"�����\" />",3)." = �����</td></tr>
			<tr><td>".str_repeat("<img src=\"modules/users/img/star4.gif\" border=\"0\"  width=\"11\" height=\"10\" alt=\"���������\" />",4)." = ���������</td></tr>
			<tr><td>".str_repeat("<img src=\"modules/users/img/star5.gif\" border=\"0\"  width=\"11\" height=\"10\" alt=\"�������������\" />",5)." = �������������</td></tr>
			</table>";
		}
	break 1;

	case "save":
		echo $Siteman->lang["datasaved"]."<br /><br /><table cellspacing=\"0\" cellpadding=\"2\">";
		if ($usernameerror == 1) {
			echo"<tr><td>".$Siteman->lang["username"]."</td><td>".$values["username"]."</td></tr>";
		}
		else if (strlen($usernameerror > 1)) {
			echo"<tr><td colspan=\"2\" class=\"error\">".$Siteman->lang[$usernameerror]."</td></tr>";
		}
		if ($passworderror == 1) {
			echo"<tr><td>".$Siteman->lang["password"]."</td><td><select><option>".$Siteman->lang["clicktoshow"]."</option><option>".$_POST["newpass"]."</option></select></td></tr>";
		}
		else if (strlen($passworderror) > 1) {
			echo"<tr><td colspan=\"2\" class=\"error\">".$Siteman->lang[$passworderror]."</td></tr>";
		}
		if ($emailerror == 1) {
			echo"<tr><td>".$Siteman->lang["email"]."</td><td>".$values["email"]."</td></tr>";
		}
		else if (strlen($emailerror) > 1) {
			echo"<tr><td colspan=\"2\" class=\"error\">".$Siteman->lang[$emailerror]."</td></tr>";
		}
		if ($chhideemail) {
			echo"<tr><td>".$Siteman->lang["hideemail"]."</td><td>".str_replace("1",$Siteman->lang["yes"],str_replace("0",$Siteman->lang["no"],$values["hide_email"]))."</td></tr>";
		}
		if (strlen($_POST["squest"]) > 0 && $chsquest) {
			echo"<tr><td>".$Siteman->lang["squest"]."</td><td>".$values["squest"]."</td></tr>";
		}
		if ($sanserror == 1) {
			echo"<tr><td>".$Siteman->lang["sans"]."</td><td><select><option>".$Siteman->lang["clicktoshow"]."</option><option>".$_POST["sans"]."</option></select></td></tr>";
		}
		else if (strlen($sanserror) > 1) {
			echo"<tr><td colspan=\"2\" class=\"error\">".$Siteman->lang[$sanserror]."</td></tr>";
		}
		echo"</table><br /><br /><a href=\"index.php?module=users\">".$Siteman->lang["rtmyaccount"]."</a>";
	break 1;

	default:
		echo $Siteman->lang["editaccount"]."<br /><br /><form action=\"index.php?module=users&amp;do=save\" method=\"post\">
		<table cellspacing=\"0\" cellpadding=\"2\"><tr><td>".$Siteman->lang["username"]."</td><td><input type=\"text\" name=\"username\" size=\"35\" value=\"".$Siteman->userinfo["username"]."\" maxlength=\"40\" readonly=\"TRUE\" /></td></tr>
		<tr><td>".$Siteman->lang["oldpass"]."</td><td><input type=\"password\" name=\"oldpass\" size=\"35\" /></td></tr>
		<tr><td>".$Siteman->lang["newpass"]."</td><td><input type=\"password\" name=\"newpass\" size=\"35\" /></td></tr>
		<tr><td>".$Siteman->lang["rnewpass"]."</td><td><input type=\"password\" name=\"rnewpass\" size=\"35\" /></td></tr>
		<tr><td>".$Siteman->lang["email"]."</td><td><input type=\"text\" name=\"email\" size=\"35\" value=\"".$Siteman->userinfo["email"]."\" /></td></tr>
		<tr><td>".$Siteman->lang["hideemail"]."</td><td><table cellspacing=\"0\" cellpadding=\"1\"><tr><td><input type=\"radio\" name=\"hide_email\" value=\"1\" ";
		if ($Siteman->userinfo["hide_email"]) {
			echo"checked ";
		}
		echo"/></td><td>".$Siteman->lang["yes"]."&nbsp;&nbsp;&nbsp;&nbsp;</td><td><input type=\"radio\" name=\"hide_email\" value=\"0\" ";
		if (!$Siteman->userinfo["hide_email"]) {
			echo"checked ";
		}
		echo"/></td><td>".$Siteman->lang["no"]."</td></tr></table></td></tr>
		<tr><td>".$Siteman->lang["fsign"]."</td><td><input type=\"text\" name=\"forum_signature\" size=\"35\" value=\"".htmlspecialchars($Siteman->userinfo["forum_signature"])."\" /></td></tr>
		<tr><td>".$Siteman->lang["squest"]."</td><td><input type=\"text\" name=\"squest\" size=\"35\" value=\"".$Siteman->userinfo["squest"]."\" /></td></tr>
		<tr><td>".$Siteman->lang["sans"]."</td><td><input type=\"password\" name=\"sans\" size=\"35\" /></td></tr>
		<tr><td>".$Siteman->lang["repsans"]."</td><td><input type=\"password\" name=\"repsans\" size=\"35\" /></td></tr>
		<tr><td></td><td align=\"right\"><input type=\"submit\" value=\"".$Siteman->lang["save"]."\" /></td></tr></table></form>";
	break 1;
	}
}
else {
	switch ($do) {

	case "regstep":
		$errstart = "<br /><br />".$Siteman->lang["error"]."<br /><span class=\"error\">";
		$errstop = "</span>";
		if (strlen($_POST["username"]) == 0 || strlen($_POST["pass"]) == 0 || strlen($_POST["email"]) == 0 || strlen($_POST["squest"]) == 0 || strlen($_POST["sans"]) == 0) {
			echo $errstart.$Siteman->lang["missfields"].$errstop;
		}
		else if (strlen($_POST["username"]) > 40) {
			echo $errstart.$Siteman->lang["toolong"].$errstop;
		}
		else if ($_POST["pass"] != $_POST["rpass"]) {
			echo $errstart.$Siteman->lang["regpassnomatch"].$errstop;
		}
		else if ($_POST["sans"] != $_POST["repsans"]) {
			echo $errstart.$Siteman->lang["sansnomatch"].$errstop;
		}
		else if (substr_count($_POST["fsign"],"size=") > 0 || substr_count($_POST["fsign"],"font-size:") > 0) {
			echo $errstart.$Siteman->lang["invalidhtml"].$errstop;
		}
		else if (substr_count($_POST["email"],"@") != 1 || substr_count($_POST["email"],".") < 1) {
			echo $errstart.$Siteman->lang["invalidadress"].$errstop;
		}
		else if (substr_count($_POST["username"],"<") > 0 || substr_count($_POST["username"],">") > 0 || substr_count($_POST["username"],"'") > 0 || substr_count($_POST["username"],'"') > 0 || substr_count($_POST["username"],"\\") > 0) {
			echo $errstart.$Siteman->lang["invalidchar"].$errstop;
		}
		else {
			$newusername = strtolower($_POST["username"]);
			$registered = $db->select(array("table" => "users","db" => "siteman","where" => array("strLower(username) = $newusername")));
			if (strlen($registered[0]["username"]) > 0) {
				echo $errstart.$Siteman->lang["nametaken"].$errstop;
			}
			else {
				$newmail = strtolower($_POST["email"]);
				$registered = $db->select(array("table" => "users","db" => "siteman","where" => array("email = $newmail")));
				if (strlen($registered[0]["email"]) > 0) {
					echo $errstart.$Siteman->lang["emailtaken"].$errstop;
				}
				else {
					echo"<br /><br /><b>".$Siteman->lang["datarecorded"]."</b><br /><br />
					<table cellspacing=\"0\" cellpadding=\"2\"><tr><td>".$Siteman->lang["username"]."</td><td>".$_POST["username"]."</td></tr>
					<tr><td>".$Siteman->lang["password"]."</td><td><select><option>".$Siteman->lang["clicktoshow"]."</option><option>".$_POST["pass"]."</option></select></td></tr>
					<tr><td>".$Siteman->lang["email"]."</td><td>".strtolower($_POST["email"])."</td></tr>
					<tr><td>".$Siteman->lang["hideemail"]."</td><td>";
					if ($_POST["hideemail"]) { echo $Siteman->lang["yes"]; } else { echo $Siteman->lang["no"]; }
					echo"</td></tr><tr><td>".$Siteman->lang["fsign"]."</td><td>".$_POST["fsign"]."</td></tr>
					<tr><td>".$Siteman->lang["squest"]."</td><td>".stripslashes($_POST["squest"])."</td></tr>
					<tr><td>".$Siteman->lang["sans"]."</td><td><select><option>".$Siteman->lang["clicktoshow"]."</option><option>".$_POST["sans"]."</option></select></td></tr>
					<tr><td colspan=\"2\">".$Siteman->lang["arecorrect"]."</td></tr>
					<tr><td align=\"right\"><form action=\"index.php?module=users&amp;do=regcomplete\" method=\"post\">
					<input type=\"hidden\" name=\"username\" value=\"".$_POST["username"]."\" />
					<input type=\"hidden\" name=\"password\" value=\"".$_POST["pass"]."\" />
					<input type=\"hidden\" name=\"email\" value=\"".strtolower($_POST["email"])."\" />
					<input type=\"hidden\" name=\"hideemail\" value=\"".$_POST["hideemail"]."\" />
					<input type=\"hidden\" name=\"fsign\" value=\"".$_POST["fsign"]."\" />
					<input type=\"hidden\" name=\"squest\" value=\"".stripslashes($_POST["squest"])."\" />
					<input type=\"hidden\" name=\"sans\" value=\"".stripslashes($_POST["sans"])."\" />
					<input type=\"submit\" value=\"".$Siteman->lang["yes"]."\" /></form></td>
					<td><form><input type=\"button\" value=\"".$Siteman->lang["no"]."\" onclick=\"window.history.back();\" /></form></td></tr></table>";
				}
			}
		}
	break 1;

	case "regcomplete":
		if ($Siteman->settings["user_validation"]) {
			echo"<br /><br />".$Siteman->lang["mustvalidate"];
		}
		else {
			echo"<br /><br />".$Siteman->lang["wascompleted"]."<br /><br />";
			$Siteman->show_loginbox();
		}
	break 1;

	default:
		echo"<form action=\"index.php?module=users&amp;do=regstep\" method=\"post\">
		<table cellspacing=\"0\" cellpadding=\"2\"><tr><td>".$Siteman->lang["reguname"]."</td><td><input type=\"text\" name=\"username\" size=\"30\" /></td></tr>
		<tr><td>".$Siteman->lang["regpass"]."</td><td><input type=\"password\" name=\"pass\" size=\"30\" /></td></tr>
		<tr><td>".$Siteman->lang["rpass"]."</td><td><input type=\"password\" name=\"rpass\" size=\"30\" /></td></tr>
		<tr><td>".$Siteman->lang["email"]."</td><td><input type=\"text\" name=\"email\" size=\"30\" /></td></tr>
		<tr><td>".$Siteman->lang["hideemail"]."</td><td><table cellspacing=\"0\" cellpadding=\"2\"><tr><td><input type=\"radio\" name=\"hideemail\" value=\"1\" checked/></td><td>".$Siteman->lang["yes"]."</td><td><input type=\"radio\" name=\"hideemail\" value=\"0\" /></td><td>".$Siteman->lang["no"]."</td></tr></table></td></tr>
		<tr><td>".$Siteman->lang["fsign"]."</td><td><input type=\"text\" name=\"fsign\" size=\"30\" /></td></tr>
		<tr><td>".$Siteman->lang["squest"]."</td><td><input type=\"text\" name=\"squest\" size=\"30\" /></td></tr>
		<tr><td>".$Siteman->lang["sans"]."</td><td><input type=\"password\" name=\"sans\" size=\"30\" /></td></tr>
		<tr><td>".$Siteman->lang["repsans"]."</td><td><input type=\"password\" name=\"repsans\" size=\"30\" /></td></tr>
		<tr><td></td><td><input type=\"submit\" value=\"".$Siteman->lang["continue"]."\" /></td></tr></table></form>";
	break 1;

	}
}
?>