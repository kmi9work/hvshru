<?php
function online() {
	global $Siteman, $db;
	echo '������ �� �����:<br /><br />';
	$guests = $db->table_count("online","siteman");
	if ($guests >= 1) {
	echo '�����: <b>'.$guests.'</b><br />';
	}
	if ($Siteman->loginok && $Siteman->userinfo["level"] >= 4) {
		$guestsip = $db->select(array("table" => "online","db" => "siteman"));
		foreach ($guestsip as $guestip) {  
			echo '<a href="http://www.nic.ru/whois/?ip='.$guestip['ip'].'">'.$guestip['ip'].'</a><br />';
		}
	}
	$userdb = $db->select(array("table" => "users","db" => "siteman"));
	$times = time()-300;
	$lastvisit = $db->select(array("table" => "last_online","db" => "siteman","where" => array("last_online >= ".$times)));
	foreach ($lastvisit as $lastone) {  
		$userlast = $lastone['id'] - 1;
		$usr_status = '';
		if ($userdb[$userlast]['level'] == 5) { $usr_status = '<font color="#ff0000">'.$userdb[$userlast]['username'].'</font>'; }
		elseif ($userdb[$userlast]['level'] == 3 || $userdb[$userlast]['level'] == 4) { $usr_status = '<font color="green">'.$userdb[$userlast]['username'].'</font>'; }
		else { $usr_status = $userdb[$userlast]['username']; }
		echo $usr_status.'<br />';
	}
}
?>