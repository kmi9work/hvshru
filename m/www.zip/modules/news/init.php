<?php
require_once('./modules/news/functions.php');
$Siteman->load_lang("news");

$act = (isset($_GET["act"])) ? $_GET["act"] : "default";

if ($act == "show") {
	$cat = $_GET["c"];
	$id = $_GET["id"];
	$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = $cat")));
	$news = $db->select(array("table" => "nws","db" => "news","where" => array("id = $id")));
	$Siteman->content = $Siteman->lang["news"].' -> '.$cats[0]["title"].' -> '.$news[0]["title"];
	$news[0]["count"]++;
	$db->update(array("table" => "nws","db" => "news","where" => array("id = $id"),"values" => array("count" => $news[0]["count"])));
}
else if ($act == "list") {
	$cat = $_GET["c"];
	$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = $cat")));
	$Siteman->content = $Siteman->lang["news"].' -> '.$cats[0]["title"];
}
else if ($act == "archive") {
	$Siteman->content = $Siteman->lang["news"].' -> '.$Siteman->lang["news_archive"];
}
else {
	$Siteman->content = $Siteman->lang["news"];
}
switch ($act) {
	case "savecom":
		$cat = global_replace($_POST["cat"]);
		$id = global_replace($_POST["news"]);
		$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = $cat")));
		$news = $db->select(array("table" => "nws","db" => "news","where" => array("id = $id")));
		if ($cat != "" && $id != "" && $news[0]["id_cat"] == $cat && $news[0]["id"] == $id && $cats[0]["comments"] != 0 && $Siteman->userinfo["level"] >= $cats[0]["level_comments"] && strlen($_POST["message"]) > 5 && strlen($_POST["autor"]) > 3) {
			$autor = global_replace($_POST["autor"]);
			if (strlen($autor) > $cats[0]["max_acom_size"]) {
				$autor = substr($autor,0,$cats[0]["max_acom_size"]);
			}
			$message = global_replace(Badwordcutter($_POST["message"]));
			if (strlen($message) > $cats[0]["max_mcom_size"]) {
				$message = substr($message,0,$cats[0]["max_mcom_size"]);
			}
			$db->insert(array("table" => "comments","db" => "news","values" => array("autor" => $autor,"email" => global_replace($_POST["email"]),"comment" => $message,"ip" => $_SERVER["REMOTE_ADDR"],"id_cat" => $cat,"id_nws" => $id)));
			$news[0]["comments"]++;
			$db->update(array("table" => "nws","db" => "news","where" => array("id = $id"),"values" => array("comments" => $news[0]["comments"])));
			header("Location: index.php?module=news&act=show&c=$cat&id=$id");
			exit;
		}
		else {
			header("Location: index.php?module=news&act=archive");
			exit;
		}
	break 1;
}
?>