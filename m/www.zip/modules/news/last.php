<?php
function lastnews() {
	global $db;
	$config = $db->select(array("table" => "config","db" => "news"));
	$nwscount = $db->table_count("nws","news");
	$start = ($config[0]["last_news"] >= 1) ? $nwscount-$config[0]["last_news"] : $nwscount-10;
	if ($start < 0) {
		$start = 0;
	}
	$end = $nwscount-1;
	$news = $db->select(array("table" => "nws","db" => "news","limit" => array($start,$end),"orderby" => array("id",DESC)));
	foreach($news as $nws) {
		echo '<a href="index.php?module=news&amp;act=show&amp;c='.$nws["id_cat"].'&amp;id='.$nws["id"].'" title="'.$nws["title"].'">'.$nws["title"].'</a><br />';
	}
}
?>