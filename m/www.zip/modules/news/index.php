<?php
require_once('./modules/news/functions.php');
$Siteman->load_lang("news");
$Siteman->load_lang("guestbook");

$act = (isset($_GET["act"])) ? $_GET["act"] : "default";
$cat = (isset($_GET["c"])) ? global_replace($_GET["c"]) : "";
$id = (isset($_GET["id"])) ? global_replace($_GET["id"]) : "";

switch ($act) {
	case "archive":
		$cats = $db->select(array("table" => "cats","db" => "news"));
		echo '<a href="index.php?module=news">'.$Siteman->lang["news"].'</a> &gt;&gt; '.$Siteman->lang["news_archive"].'<br />
		<table width="100%" align="center" border="0" cellspacing="10">';
		foreach ($cats as $ct) {
			$icon = ($ct["icon"] != "") ? '<img src="'.$ct["icon"].'" alt="'.$ct["title"].'" border="0" align="right" hspace="10" vspace="10">' : '';
			echo '<tr><td valign="top">'.$icon.'<a href="index.php?module=news&amp;act=list&amp;c='.$ct["id"].'" title="'.$ct["title"].'"><b>'.$ct["title"].'</b></a> ('.$ct["no_news"].')
			<br /><br />'.$ct["desc"].'</td></tr>
			<tr><td>&nbsp;</td></tr>';
		}
		echo '</table>';
	break 1;

	case "list":
		$config = $db->select(array("table" => "config","db" => "news"));
		$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = $cat")));
		$num_page = $db->select(array("table" => "nws","db" => "news","where" => array("id_cat = $cat")));
		if ($cat != "" && $cats[0]["id"] == $cat) {
			$pl = (isset($_GET["pl"])) ? $_GET["pl"] : 0;
			$nwscount = count($num_page);
			$start = $nwscount-($pl+$cats[0]["num_pages"]);
			if ($start < 0) {
				$start = 0;
			}
			$end = $nwscount-($pl+1);
			$news = $db->select(array("table" => "nws","db" => "news","where" => array("id_cat = $cat"),"limit" => array($start,$end),"orderby" => array("id",DESC)));
			$pages = ceil($nwscount/$cats[0]["num_pages"]);
			$page = ($pl/$cats[0]["num_pages"])+1;
			echo '<a href="index.php?module=news">'.$Siteman->lang["news"].'</a> &gt;&gt; '.$cats[0]["title"].'<br />';
			if ($news[0]["title"] != "") {
				echo ''.$Siteman->lang["pages"].':';
				for ($i=1;$i<=$pages;$i++) {
					if ($i == $page) {
						echo ' <b>'.$i.'</b> ';
					}
					else {
						 $nowpl = ($i-1)*$cats[0]["num_pages"];
						 echo ' <a href="index.php?module=news&amp;act=list&amp;c='.$cat.'&amp;pl='.$nowpl.'">'.$i.'</a> ';
					}
				}
				echo '<br /><br />
				<table width="100%" cellspacing="0" cellpadding="2">';
				foreach ($news as $nw) {
					$text = (strlen($nw["text"]) > $config[0]["short"]) ? substr($nw["text"],0,$config[0]["short"]-1).'... <a href="index.php?module=news&amp;act=show&amp;c='.$cat.'&amp;id='.$nw["id"].'" title="'.$nw["title"].'">'.$Siteman->lang["read_more"].' &gt;&gt;</a>' : $nw["text"];
					echo '<tr><td><table cellpadding="3" width="100%" cellspacing="0"><tr><td class="dark">
					<a href="index.php?module=news&amp;act=show&amp;c='.$cat.'&amp;id='.$nw["id"].'" title="'.$nw["title"].'"><b>'.$nw["title"].'</b></a></td>
					<td align="right" class="dark"><i>'.date($Siteman->settings["long_dateformat"],$nw["date"]+$Siteman->settings["timezone_offset"]).' by '.$nw["autor"].'</i></td></tr>
					<tr><td colspan="2" valign="top"><br />'.$text.'</td></tr>
					<tr><td colspan="2" align="right" class="dark">'.$Siteman->lang["views"].' '.$nw["count"];
					if ($cats[0]["comments"] != 0) {
						echo ', <a href="index.php?module=news&amp;act=show&amp;c='.$cat.'&amp;id='.$nw["id"].'#form">'.$Siteman->lang["comments"].'</a>: '.$nw["comments"];
					}
					echo '</td></tr></table></td></tr><tr><td>&nbsp;</td></tr>';
				}
				echo '</table><br /><br />'.$Siteman->lang["pages"].':';
				for ($i=1;$i<=$pages;$i++) {
					if ($i == $page) {
						echo ' <b>'.$i.'</b> ';
					}
					else {
						 $nowpl = ($i-1)*$cats[0]["num_pages"];
						 echo ' <a href="index.php?module=news&amp;act=list&amp;c='.$cat.'&amp;pl='.$nowpl.'">'.$i.'</a> ';
					}
				}
			}
			else {
				echo '<br />'.$Siteman->lang["not_news"];
			}
		}
		else {
			header("Location: index.php?module=news&act=archive");
			exit;
		}
	break 1;

	case "show":
		$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = $cat")));
		$show = $db->select(array("table" => "nws","db" => "news","where" => array("id = $id")));
		if ($cat != "" && $id != "" && $show[0]["id_cat"] == $cat && $show[0]["id"] == $id) {
			echo '<a href="index.php?module=news">'.$Siteman->lang["news"].'</a> &gt;&gt; <a href="index.php?module=news&amp;act=list&amp;c='.$cats[0]["id"].'">'.$cats[0]["title"].'</a> &gt;&gt; '.$show[0]["title"].'<br />
			<table width="100%" cellspacing="0" cellpadding="2">
			<tr><td align="center"><h4>'.$show[0]["title"].'</h4></td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td>'.$show[0]["text"].'</td></tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td align="right"><i>'.date($Siteman->settings["long_dateformat"],$show[0]["date"]+$Siteman->settings["timezone_offset"]).' by <b>'.$show[0]["autor"].'</b></i></td></tr></table>';
			if ($cats[0]["comments"] != 0) {
				echo '<br /><br /><a name="comments"></a><table width="100%" cellspacing="0" cellpadding="2">';
				$comments = $db->select(array("table" => "comments","db" => "news","where" => array("id_nws = $id")));
				foreach ($comments as $comm) {
					$autor = ($comm["email"] != "") ? '<a href="mailto:'.$comm["email"].'" title="'.$comm["email"].'">'.$comm["autor"].'</a>' : $comm["autor"];
					echo '<tr><td class="dark"><b>'.$autor.'</b></td><td class="dark" align="right"><i>'.date($Siteman->settings["long_dateformat"],$comm["date"]+$Siteman->settings["timezone_offset"]).'</i></td></tr>
					<tr><td colspan="2"><br />'.smiliehtml(bb_replace(url_replace($comm["comment"]))).'</td></tr>
					<tr><td colspan="2">&nbsp;</td></tr>';
				}
				echo '</table><a name="form"></a>
				<br /><br /><table width="90%" border="0">';
				if ($Siteman->userinfo["level"] >= $cats[0]["level_comments"]) {
					$postautor = (isset($Siteman->userinfo["username"])) ? $Siteman->userinfo["username"] : 'Guest';
					echo '<tr><td align="center">'.$Siteman->lang["comm_in_news"].' "'.$show[0]["title"].'"</td></tr>
					<tr><td align="center"><form action="index.php?module=news&amp;act=savecom" method="post" name="comform" id="comform">
					<table width="80%" border="0"><tr><td>'.$Siteman->lang["name"].'<font color="#ff0000">*</font><br />(max. '.$cats[0]["max_acom_size"].' '.$Siteman->lang["char"].'):</td>
					<td><input type="text" name="autor" size="25" maxlength="'.$cats[0]["max_acom_size"].'" value="'.$postautor.'" /></td></tr>
					<tr><td>'.$Siteman->lang["email"].':</td><td><input type="text" name="email" size="25" maxlength="60" /></td></tr>
					<tr><td>'.$Siteman->lang["text"].'<font color="#ff0000">*</font><br />(max. '.$cats[0]["max_mcom_size"].' '.$Siteman->lang["char"].', '.$Siteman->lang["char_left"].' <input type="text" size="2" onkeydown="update();" onkeyup="update();" name="chars" id="chars" value="'.$cats[0]["max_mcom_size"].'" readonly="TRUE"/>):</td>
					<td><textarea onkeydown="update();" onkeyup="update();" name="message" id="message" rows="7" cols="38"></textarea></td></tr>
					<input type="hidden" name="news" value="'.$show[0]["id"].'" />
					<input type="hidden" name="cat" value="'.$show[0]["id_cat"].'" />
					<tr><td></td><td><input type="submit" value="'.$Siteman->lang["sign"].'" /></td></tr></table></form>
					<script language="Javascript" type="text/javascript">
					function code (bbcod) {
						document.comform.message.value = document.comform.message.value + \'[\' + bbcod + \'][/\' + bbcod + \']\';
						document.comform.message.focus();
					}
					function update() {
						if (document.comform.message.value.length > '.$cats[0]["max_mcom_size"].') {
							document.comform.message.value = document.comform.message.value.substring(0,'.$cats[0]["max_mcom_size"].');
						}
						var left = '.$cats[0]["max_mcom_size"].'-document.comform.message.value.length;
						document.comform.chars.value = left;
					}
					</script>
					</td></tr><tr><td align="center">'.$Siteman->lang["textdecor"].': 
					[b]<a href="javascript:code(\'b\')" class="b"><b>'.$Siteman->lang["bold"].'</b></a>[/b] 
					[i]<a href="javascript:code(\'i\')" class="b"><i>'.$Siteman->lang["italic"].'</i></a>[/i] 
					[u]<a href="javascript:code(\'u\')" class="b"><u>'.$Siteman->lang["underline"].'</u></a>[/u]</td></tr>';
				}
				else {
					echo '<tr><td align="center"><i>'.$Siteman->lang["comm_error"].'</i></td></tr>';
				}
				echo '</table>';
			}
		}
		else {
			header("Location: index.php?module=news&act=archive");
			exit;
		}
	break 1;

	default:
		$config = $db->select(array("table" => "config","db" => "news"));
		$cats = $db->select(array("table" => "cats","db" => "news"));
		if (isset($_GET["pl"])) {
			$pl = 0;
		}
		else {
			$pl = 0;
		}
		$nwscount = $db->table_count("nws","news");
		$start = $nwscount-($pl+$config[0]["num_news"]);
		if ($start < 0) {
			 $start = 0;
		}
		$end = $nwscount-($pl+1);
		$news = $db->select(array("table" => "nws","db" => "news","limit" => array($start,$end),"orderby" => array("id",DESC)));
		echo '<table width="100%" cellspacing="0" cellpadding="2">';
		foreach ($news as $nw) {
			$id_cat = $db->select(array("table" => "cats","db" => "news","where" => array("id = ".$nw["id_cat"])));
			$icon = ($id_cat[0]["icon"] != "") ? '<img src="'.$id_cat[0]["icon"].'" alt="'.$id_cat[0]["title"].'" border="0" align="right" hspace="10" vspace="10">' : '';
			$text = (strlen($nw["text"]) > $config[0]["short"]) ? substr($nw["text"],0,$config[0]["short"]-1).'... <a href="index.php?module=news&amp;act=show&amp;c='.$id_cat[0]["id"].'&amp;id='.$nw["id"].'" title="'.$nw["title"].'">'.$Siteman->lang["read_more"].' &gt;&gt;</a>' : $nw["text"];
			echo '<tr><td><table cellpadding="3" width="100%" cellspacing="0"><tr><td class="dark">
			<a href="index.php?module=news&amp;act=show&amp;c='.$id_cat[0]["id"].'&amp;id='.$nw["id"].'" title="'.$nw["title"].'"><b>'.$nw["title"].'</b></a></td>
			<td align="right" class="dark"><i>'.date($Siteman->settings["long_dateformat"],$nw["date"]+$Siteman->settings["timezone_offset"]).' by '.$nw["autor"].'</i></td></tr>
			<tr><td valign="top" colspan="2">'.$icon.$text.'</td></tr>
			<tr><td class="dark">'.$Siteman->lang["cat"].': <a href="index.php?module=news&amp;act=list&amp;c='.$id_cat[0]["id"].'" title="'.$id_cat[0]["title"].'">'.$id_cat[0]["title"].'</a></td>
			<td align="right" class="dark">'.$Siteman->lang["views"].' '.$nw["count"];
			if ($id_cat[0]["comments"] != 0) {
				echo ', <a href="index.php?module=news&amp;act=show&amp;c='.$id_cat[0]["id"].'&amp;id='.$nw["id"].'#form">'.$Siteman->lang["comments"].'</a>: '.$nw["comments"];
			}
			echo '</td></tr></table></td></tr><tr><td>&nbsp;</td></tr>';
		}
		echo '</table><br /><br /><center><a href="index.php?module=news&amp;act=archive" title="'.$Siteman->lang["news_archive"].'"><b>'.$Siteman->lang["news_archive"].'</b></a></center>';
	break 1;
}
?>
