<?php
require_once('./modules/news/functions.php');
if ($Siteman->userinfo["level"] >= 3) {		

	$mdo = (isset($_GET["mdo"])) ? $_GET["mdo"] : "default";
	$cat = (isset($_GET["c"])) ? $_GET["c"] : "";
	$id = (isset($_GET["id"])) ? $_GET["id"] : "";

	switch ($mdo) {
		case "savecfg":
			$db->update(array("table" => "config","db" => "news","where" => array("id = 1"),"values" => array("short" => global_replace(trim($_POST["short"])),"num_news" => global_replace(trim($_POST["num_news"])),"last_news" => global_replace(trim($_POST["last_news"])))));
			$mdo = "default";
		break 1;

		case "savecomm":
			$db->update(array("table" => "comments","db" => "news","where" => array("id = $id"),"values" => array("autor" => global_replace($_POST["autor"]),"email" => global_replace($_POST["email"]),"comment" => global_replace($_POST["message"]))));
			$mdo = "listcomm";
		break 1;

		case "rcc":
			$db->update(array("table" => "nws","db" => "news","where" => array("id = $id"),"values" => array("count" => 0)));
			$mdo = "listnews";
		break 1;

		case "savecat":
			$db->update(array("table" => "cats","db" => "news","where" => array("id = $cat"),"values" => array("title" => stripslashes($_POST["title"]),"desc" => stripslashes(str_replace("\n","<br />",$_POST["desc"])),"icon" => stripslashes($_POST["icon"]),"num_pages" => stripslashes($_POST["num_pages"]),"comments" => $_POST["comments"],"level_comments" => $_POST["level_comments"],"max_acom_size" => stripslashes($_POST["acom_size"]),"max_mcom_size" => stripslashes($_POST["mcom_size"]))));
			header("Location: admin.php?module=news&mdo=listcat");
			exit;
		break 1;

		case "docreatecat":
			$db->insert(array("table" => "cats","db" => "news","values" => array("title" => stripslashes($_POST["title"]),"desc" => stripslashes(str_replace("\n","<br />",$_POST["desc"])),"icon" => stripslashes($_POST["icon"]),"num_pages" => stripslashes($_POST["num_pages"]),"comments" => $_POST["comments"],"level_comments" => $_POST["level_comments"],"max_acom_size" => stripslashes($_POST["acom_size"]),"max_mcom_size" => stripslashes($_POST["mcom_size"]))));
			header("Location: admin.php?module=news&mdo=listcat");
			exit;
		break 1;

		case "savenews":
			$news = $db->select(array("table" => "nws","db" => "news","where" => array("id = $id")));
			$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = ".$news[0]["id_cat"])));
			if (isset($_POST["content"])) {
				if (substr_count(stripslashes($_POST["content"]),"<!-- REMOVE -->") > 0) {
					$contentarray = explode("<!-- REMOVE -->",stripslashes($_POST["content"]));
					$count = (substr_count(stripslashes($_POST["content"]),"<!-- REMOVE -->"))/2;
					$content = $contentarray[$count];
				}
				else {
					$content = stripslashes($_POST["content"]);
				}
				if ($news[0]["id_cat"] != $_POST["cat"]) {
					$newcats = $db->select(array("table" => "cats","db" => "news","where" => array("id = ".$_POST["cat"])));
					$cats[0]["no_news"]--;
					$db->update(array("table" => "cats","db" => "news","where" => array("id = ".$news[0]["id_cat"]),"values" => array("no_news" => $cats[0]["no_news"])));
					$db->update(array("table" => "nws","db" => "news","where" => array("id = $id"),"values" => array("title" => stripslashes($_POST["title"]),"text" => $content,"autor" => stripslashes($_POST["autor"]),"id_cat" => $_POST["cat"])));
					$db->update(array("table" => "comments","db" => "news","where" => array("id_nws = $id"),"values" => array("id_cat" => $_POST["cat"])));
					$newcats[0]["no_news"]++;
					$db->update(array("table" => "cats","db" => "news","where" => array("id = ".$_POST["cat"]),"values" => array("no_news" => $newcats[0]["no_news"])));
				}
				else {
					$db->update(array("table" => "nws","db" => "news","where" => array("id = $id"),"values" => array("title" => stripslashes($_POST["title"]),"text" => $content,"autor" => stripslashes($_POST["autor"]),"id_cat" => $_POST["cat"])));
				}
				if ($_POST["save"] == "���������") {
					header("Location: admin.php?module=news&mdo=ednews&id=".$id);
					exit;
				}
				else {
					header("Location: admin.php?module=news&mdo=listnews");
					exit;
				}
			}
		break 1;

		case "docreatenews":
			$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = ".$_POST["cat"])));
			if (isset($_POST["content"])) {
				if (substr_count(stripslashes($_POST["content"]),"<!-- REMOVE -->") > 0) {
					$contentarray = explode("<!-- REMOVE -->",stripslashes($_POST["content"]));
					$count = (substr_count(stripslashes($_POST["content"]),"<!-- REMOVE -->"))/2;
					$content = $contentarray[$count];
				}
				else {
					$content = stripslashes($_POST["content"]);
				}
				$db->insert(array("table" => "nws","db" => "news","values" => array("title" => stripslashes($_POST["title"]),"text" => $content,"autor" => stripslashes($_POST["autor"]),"id_cat" => $_POST["cat"],"comments" => 0,"count" =>0)));
				$cats[0]["no_news"]++;
				$db->update(array("table" => "cats","db" => "news","where" => array("id = ".$_POST["cat"]),"values" => array("no_news" => $cats[0]["no_news"])));
				header("Location: admin.php?module=news&mdo=listnews");
				exit;
			}
		break 1;

		case "dodelcat":
			$db->delete(array("table" => "comments","db" => "news","where" => array("id_cat = $cat")));
			$db->delete(array("table" => "nws","db" => "news","where" => array("id_cat = $cat")));
			$db->delete(array("table" => "cats","db" => "news","where" => array("id = $cat")));
			header("Location: admin.php?module=news&mdo=listcat");
			exit;
		break 1;

		case "dodelnews":
			$delnews = $db->select(array("table" => "nws","db" => "news","where" => array("id = $id")));
			$cats = $db->select(array("table" => "cats","db" => "news","where" => array("id = ".$delnews[0]["id_cat"])));
			$db->delete(array("table" => "comments","db" => "news","where" => array("id_nws = $id")));
			$db->delete(array("table" => "nws","db" => "news","where" => array("id = $id")));
			$cats[0]["no_news"]--;
			$db->update(array("table" => "cats","db" => "news","where" => array("id = ".$delnews[0]["id_cat"]),"values" => array("no_news" => $cats[0]["no_news"])));
			header("Location: admin.php?module=news&mdo=listnews");
			exit;
		break 1;

		case "dodelcomm":
			$delcomm = $db->select(array("table" => "comments","db" => "news","where" => array("id = $id")));
			$news = $db->select(array("table" => "nws","db" => "news","where" => array("id = ".$delcomm[0]["id_nws"])));
			$db->delete(array("table" => "comments","db" => "news","where" => array("id = $id")));
			$news[0]["comments"]--;
			$db->update(array("table" => "nws","db" => "news","where" => array("id = ".$delcomm[0]["id_nws"]),"values" => array("comments" => $news[0]["comments"])));
			header("Location: admin.php?module=news&mdo=listcomm");
			exit;
		break 1;
	}
}
?>