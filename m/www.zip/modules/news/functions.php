<?php
function Badwordcutter($text) {
	global $db;
	$badwords = $db->select(array("table" => "badwords","db" => "siteman"));
	foreach($badwords as $badword) {
		$text = str_replace($badword["word"], $badword["good"], $text);
	}
	return $text;
}
function global_replace($st) {
	$st = htmlspecialchars($st, ENT_QUOTES);
	$st = stripslashes($st);
	$st = str_replace("\t","",$st);
	$st = str_replace("\r","",$st);
	$st = str_replace("&#8249;","",$st);
	$st = str_replace("&#8250;","",$st);
	$st = str_replace("&nbsp;", " ", $st);
	return $st;
}
function smiliehtml($text) {
	$text = str_replace(':)','<img src="modules/guestbook/smilies/smile.gif" border="0">',$text);
	$text = str_replace(':(','<img src="modules/guestbook/smilies/sad.gif" border="0">',$text);
	$text = str_replace(';)','<img src="modules/guestbook/smilies/wink.gif" border="0">',$text);
	$text = str_replace(':cool:','<img src="modules/guestbook/smilies/cool.gif" border="0">',$text);
	$text = str_replace(':mad:','<img src="modules/guestbook/smilies/mad.gif" border="0">',$text);
	$text = str_replace(':D','<img src="modules/guestbook/smilies/biggrin.gif" border="0">',$text);
	$text = str_replace(':rolleyes:','<img src="modules/guestbook/smilies/rolleyes.gif" border="0">',$text);
	return $text;
}
function bb_replace($st) {
	$st = str_replace("\n","<br />",$st);
	$st = str_replace("[b]","<b>",$st);
	$st = str_replace("[/b]","</b>",$st);
	$st = str_replace("[i]","<i>",$st);
	$st = str_replace("[/i]","</i>",$st);
	$st = str_replace("[u]","<u>",$st);
	$st = str_replace("[/u]","</u>",$st);
	return $st;
}
function url_replace($st) {
	$st = preg_replace("/(?<!\\/)(www\\.[\\S]+)/si",'<a href="http://\\1" target="_blank">\\1</a>',$st);
	$st = preg_replace("/(?<!\\/)(ftp\\.[\\S]+)/si",'<a href="ftp://\\1" target="_blank">\\1</a>',$st);
	$st = preg_replace("/(?<!\")(http|ftp):\\/\\/(\\S+)/si",'<a href="\\1://\\2" target="_blank">\\2</a>',$st);
	$st = preg_replace("/(?<!\\/)([0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,4})/si",'<a href="mailto:\\1">\\1</a>',$st);
	return $st;
}
?>